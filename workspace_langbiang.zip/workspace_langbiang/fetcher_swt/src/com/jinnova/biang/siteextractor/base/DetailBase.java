package com.jinnova.biang.siteextractor.base;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.browser.ProgressListener;
import org.eclipse.swt.widgets.Composite;

import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;

public abstract class DetailBase extends FetcherBase implements ProgressListener {
	
	private int itemCount = 1;
	private int itemCountSuccess = 0;
	
	private long loadTimeStart, loadTimeEnd, fetchTimeStart, fetchTimeEnd;
	
	private final Object eventCompleteLock = new Object();
	private boolean waitingEventComplete = false;

	private Iterator<Ento> iterator;

	protected HashMap<String, Extractor>  extractors = new HashMap<>();

	private String debuggingUrl;
	
	public abstract String getCatId();
	
	public abstract int getMinFieldCount();
	
	public abstract void setup();

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 * @throws EntoPersistentException 
	 */
	public void createPartControl(final Composite parent) throws EntoPersistentException {
		
		browser = new Browser(parent, SWT.None);
		browser.addProgressListener(this);
		spec = EntoManager.instance.getSpec(getCatId());
		iterator = spec.getAllEntos().iterator();
		//debuggingUrl = "http://vatgia.com/1256/1721819/thong_so_ky_thuat/hp-pro-3330-mt-qt035av-intel-core-i3-2100-3-1ghz-ram-2gb-hdd-500gb-vga-intel-hd-graphics-pc-dos-kh%C3%B4ng-k%C3%A8m-m%C3%A0n-h%C3%ACnh.html";
		debugging = debuggingUrl != null;
		setup();
		loadPage();
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				while (true) {
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
					synchronized (eventCompleteLock) {
						if (waitingEventComplete && System.currentTimeMillis() - loadTimeStart > 10000) {
							waitingEventComplete = false;
							ento.setFieldValue("fetch_stat", "error_loading_nonstop");
							System.out.println("*****error_loading_nonstop");
							parent.getDisplay().asyncExec(new Runnable() {
								
								@Override
								public void run() {
									try {
										loadPage();
									} catch (EntoPersistentException e) {
										e.printStackTrace();
									}
								}
							});
						}
					}
				}
			}
		}).start();
	}
	
	private void loadPage() throws EntoPersistentException {
		
		if (ento != null) {
			updateEnto();
		}
		
		do {
			if (!iterator.hasNext()) {
				return;
			}
			ento = iterator.next();
			if (ento.getFieldValue("fetch_stat") == null) {
				break;
			}
		} while (true);
		
		String url = debuggingUrl;
		if (url == null) {
			url = ento.getFieldValue("vg_url");
			int i = url.indexOf("/");
			i = url.indexOf("/", i + 1);
			i = url.indexOf("/", i + 1);
			i = url.indexOf("/", i + 1);
			i = url.indexOf("/", i + 1);
			url = url.substring(0, i) + "/thong_so_ky_thuat" + url.substring(i);
		}
		//url = "http://vatgia.com/6243/2612401/thong_so_ky_thuat/apple-ipad-mini-apple-a5x-1-0ghz-1gb-ram-16gb-flash-driver-7-9-inch-ios-6-wifi-model-black.html";
		//url = "http://vatgia.com/6243/2768958/thong_so_ky_thuat/aoson-m71gs-allwinner-a10-1-5ghz-1gb-ram-8gb-flash-driver-7-inch-android-os-v4-0.html";
		fetchTimeEnd = System.currentTimeMillis();
		System.out.println(new Date() + " - " + itemCount++ + " (" + itemCountSuccess + "): " + (loadTimeEnd - loadTimeStart) + 
				"|" + (fetchTimeEnd - fetchTimeStart) + ": " + url);
		loadTimeStart = System.currentTimeMillis();
		ento.setFieldValue("fetch_stat", "processed");
		browser.setUrl(url);
		
		synchronized (eventCompleteLock) {
			waitingEventComplete = true;
		}
	}
	
	@Override
	public void completed(ProgressEvent arg0) {
		synchronized (eventCompleteLock) {
			if (!waitingEventComplete) {
				return;
			}
			waitingEventComplete = false;
		}
		loadTimeEnd = System.currentTimeMillis();
		fetchTimeStart = System.currentTimeMillis();
		try {
			processOnePage();
		} catch (SWTException e) {
			ento.setFieldValue("fetch_stat", "error_scrip_nav");
			System.out.println("*****SWTException at field " + ": " + e.getMessage());
		}
		if (debuggingUrl != null) {
			return;
		}
		try {
			loadPage();
		} catch (EntoPersistentException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void changed(ProgressEvent arg0) {
		
	}
	
	private void processOnePage() {
		
		String deviceMame = (String) browser.evaluate("return $(window.document.getElementById('header_navigate_extend')).text()");
		System.out.println(deviceMame);
		ento.setFieldValue("brand", deviceMame);
		
		browser.evaluate("fetchingImageRow = window.document.getElementById('detail_product_picture_thumbnail')");
		boolean thumbsExist = (Boolean) browser.evaluate("return fetchingImageRow != null");
		if (thumbsExist) {
			browser.evaluate("fetchingImageRow = fetchingImageRow.getElementsByTagName('table')[0]");
			int cellIndex = 0;
			LinkedList<String> imageUrls = new LinkedList<>();
			while (true) {
				browser.evaluate("imageCell = fetchingImageRow.cells[" + cellIndex++ + "]");
				//browser.evaluate("alert(imageCell)");
				if ((Boolean) browser.evaluate("return imageCell == null")) {
					break;
				}
				String oneImg = (String) browser.evaluate("return imageCell.getElementsByTagName('a')[0].href");
				System.out.println("Image: " + oneImg);
				imageUrls.add(oneImg);
			}
			ento.setFieldValue("image_origs", imageUrls);
		} else {
			browser.evaluate("fetchingImages = window.document.getElementById('detail_product_picture_main')");
			//String oneImageUrl = (String) browser.evaluate("return fetchingImages.firstChild.nextSibling.nextSibling.href");
			try {
				String oneImageUrl = (String) browser.evaluate("return fetchingImages.getElementsByTagName('a')[0].href");
				System.out.println("Image: " + oneImageUrl);
				ento.setFieldValue("image_origs", oneImageUrl);
			} catch (SWTException e) {
				System.out.println("Product has no images: ok, pass on");
			}
		}
		
		browser.evaluate("fetchingTable = window.document.getElementById('detail_product_technical')");
		browser.evaluate("fetchingTable = fetchingTable.getElementsByTagName('table')[0]");
		//int fieldSkipCount = 0;
		int extractedFieldCount = 0;
		int tableRowIndex = 0;
		while (true) {

			browser.evaluate("fetchingRow = fetchingTable.rows[" + tableRowIndex++ + "]");
			boolean finished = (Boolean) browser.evaluate("return fetchingRow == null || fetchingRow.cells == null");
			if (finished) {
				break;
			}
			
			//skip title row
			int cellCount = ((Double) browser.evaluate("return fetchingRow.cells.length")).intValue();
			if (cellCount < 2) {
				continue;
			}
			
			String encounteredFieldName = (String) browser.evaluate("return $(fetchingRow.cells[0]).text()");
			
			Extractor ext = extractors.get(encounteredFieldName.trim());
			if (ext != null) {
				try {
					String encounteredFieldValue = null;
					if (ext instanceof ExtractorHref) {
						if (((ExtractorHref) ext).isHrefValue()) {
							encounteredFieldValue = (String) browser.evaluate(
								"return fetchingRow.cells[1].getElementsByTagName('a')[0].href");
						} else if (((ExtractorHref) ext).isInnerHTML()) {
							encounteredFieldValue = (String) browser.evaluate(
									"return fetchingRow.cells[1].innerHTML");
						}
					}
					if (encounteredFieldValue == null) {
						encounteredFieldValue = (String) browser.evaluate("return $(fetchingRow.cells[1]).text()");
					}
					//System.out.println(encounteredFieldName + "=" + encounteredFieldValue);
					ext.extract(encounteredFieldValue);
					extractedFieldCount++;
				} catch (RuntimeException e) {
					ento.setFieldValue("fetch_stat", "error_extract_" + encounteredFieldName);
					System.out.println("*****RuntimeException at field " + encounteredFieldName + ": " + e.getMessage());
					return;
				}
			} else {
				String encounteredFieldValue = (String) browser.evaluate("return $(fetchingRow.cells[1]).text()");
				System.out.println("*****Missing extractor for " + encounteredFieldName + "=" + encounteredFieldValue);
				ento.setFieldValue("fetch_stat", "error_extract_no_extractor_" + encounteredFieldName);
				//return;
			}
		}
		
		if (extractedFieldCount < getMinFieldCount()) {
			ento.setFieldValue("fetch_stat", "error_field_toofew_" + extractedFieldCount);
			System.out.println("*****Error: " + extractedFieldCount + " < 15 fields");
			return;
		}
		ento.setFieldValue("fetch_stat", "y");
		itemCountSuccess++;
	}

}
