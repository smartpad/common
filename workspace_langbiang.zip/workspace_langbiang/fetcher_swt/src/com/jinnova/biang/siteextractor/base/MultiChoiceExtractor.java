package com.jinnova.biang.siteextractor.base;

import java.util.StringTokenizer;

public class MultiChoiceExtractor extends ExtractNameSupport implements Extractor {
	
	/**
	 * 
	 */
	
	public MultiChoiceExtractor(FetcherBase fetcher, String fieldName, int fieldIndex) {
		super(fetcher, fieldName, fieldIndex);
	}
	
	@Override
	public void extract(String s) {
		StringTokenizer tokens = new StringTokenizer(s, "•\n");
		String pickedValues = null;
		while (tokens.hasMoreTokens()) {
			String one = tokens.nextToken();
			one = normalizeAsString(one);
			if (one == null) {
				continue;
			}
			//if (fetcher.debugging) {
				if (pickedValues == null) {
					pickedValues = one;
				} else {
					pickedValues = pickedValues + ", " + one;
				}
			//}
			try {
				fetcher.ento.setFieldValue(one, "1");
			} catch (RuntimeException e) {
				throw e;
			}
		}
		//if (fetcher.debugging) {
			System.out.println("Field " + fieldIndex + ": " + pickedValues);
		//}
	}
}