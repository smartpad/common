package com.jinnova.biang.siteextractor.base;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NumberExtractor implements Extractor {
	
	public static final String NUMBER_REGEX = "[\\d|\\.]+";
	
	private final Pattern pattern;
	private final Pattern numberPattern;
	
	/**
	 * 
	 */
	private final FetcherBase fetcher;
	private final String[] fieldNames;
	
	public boolean failOnLessNumbers = true;
	public boolean failOnMoreNumbers = true;
	
	public BigDecimal multiplier = null;
	
	private final int fieldIndex;
	
	public NumberExtractor(FetcherBase fetcher, String fieldName, int fieldIndex) {
		this(fetcher, new String[] {fieldName}, fieldIndex);
	}
	
	public NumberExtractor(FetcherBase fetcher, String[] fieldNames, int fieldIndex) {
		this(fetcher, fieldNames, fieldIndex, "");
	}
	
	public NumberExtractor(FetcherBase fetcher, String[] fieldNames, int fieldIndex, String unitRegex) {
		this.fetcher = fetcher;
		this.fieldNames = fieldNames;
		this.fieldIndex = fieldIndex;
		this.numberPattern = Pattern.compile(NUMBER_REGEX);
		this.pattern = Pattern.compile(NUMBER_REGEX + unitRegex);
		/*if (unitRegex == null) {
			this.pattern = Pattern.compile(NUMBER_REGEX + unitRegex);
		} else {
			String
			for (int i = 0; i < unitRegex.length; i++) {
				
			}
		}*/
	}
	
	@Override
	public void extract(final String s) {
		if (s.trim().isEmpty()) {
			return;
		}
		Matcher m = pattern.matcher(s);
		String[] numberValues = new String[fieldNames.length];
		for (int i = 0; i < fieldNames.length; i++) {
			if (!m.find()) {
				if (i == 0) {
					//missing the whole field
					return;
				} else if (failOnLessNumbers) {
					throw new RuntimeException("Can't extract number " + i + " from " + s);
				} else {
					return;
				}
			}
			String oneNumberWithUnit = s.substring(m.start(), m.end());
			Matcher m2 = numberPattern.matcher(oneNumberWithUnit);
			m2.find();
			numberValues[i] = oneNumberWithUnit.substring(m2.start(), m2.end());
			if (multiplier != null) {
				BigDecimal d = new BigDecimal(numberValues[i]);
				d = d.multiply(multiplier);
				numberValues[i] = d.toPlainString();
			}
		}
		if (failOnMoreNumbers && m.find()) {
			throw new RuntimeException("More numbers found after extration " + fieldNames.length + ": " + s);
		}

		System.out.print("Field " + fieldIndex + ": ");
		for (int i = 0; i < fieldNames.length; i++) {
			System.out.print(fieldNames[i] + "=" + numberValues[i] + " ");
			fetcher.ento.setFieldValue(fieldNames[i], numberValues[i]);
		}
		System.out.println();
	}
}