package com.jinnova.biang.siteextractor.base;

import java.util.HashMap;
import java.util.LinkedList;

public abstract class ExtractNameSupport implements Extractor {
	
	public boolean skipUnknowns = false;
	
	public final HashMap<String, String> nameMasks = new HashMap<>();
	
	public final LinkedList<String> ignores = new LinkedList<>();
	
	final FetcherBase fetcher;

	final String fieldName;
	
	final int fieldIndex;
	
	ExtractNameSupport(FetcherBase fetcher, String fieldName, int fieldIndex) {
		this.fetcher = fetcher;
		this.fieldName = fieldName;
		this.fieldIndex = fieldIndex;
	}
	String normalizeAsString(String name) {
		Object[] obj = normalize(name);
		if (obj == null) {
			return null;
		}
		return (String) obj[0];
	}
	
	static String replaceAllSpecials(String name) {
		name = name.trim();
		//System.out.println(one);
		name = name.replaceAll(" ", "_");
		name = name.replaceAll("-", "_");
		name = name.replaceAll("\\.", "_");
		name = name.replaceAll("\\+", "_");
		name = name.replaceAll("\n", "");
		name = name.replaceAll("/", "_");
		name = name.toLowerCase();
		return name;
	}

	/**
	 * @param args
	 */
	Object[] normalize(String name) {
		name = replaceAllSpecials(name);
		if ("".equals(name) || "_".equals(name)) {
			return null;
		}
		if (ignores.contains(name)) {
			return null;
		}
		
		boolean masked = false;
		for (String key : nameMasks.keySet()) {
			if (name.contains(key)) {
				name = nameMasks.get(key);
				masked = true;
				break;
			}
		}
		name = fieldName + name;
		if (skipUnknowns) {
			if (fetcher.ento.spec.getField(name) == null) {
				//if (fetcher.debugging) {
					System.out.println("skipped unknown field " + fieldIndex + ": " + name);
				//}
				return null;
			}
		}
		return new Object[] {name, masked};
	}

}
