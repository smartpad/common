package com.jinnova.biang.siteextractor.vatgia.mobile;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.browser.ProgressListener;
import org.eclipse.swt.widgets.Composite;

import com.jinnova.biang.siteextractor.base.FetcherBase;

public class VatGiaMobileProductList extends FetcherBase implements ProgressListener {
	
	private static final String url = "http://vatgia.com/438,month/mobile.html,";

	private PreparedStatement stmt;
	
	private int pageCount = 0;

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 * @throws SQLException 
	 */
	void createPartControl(Composite parent) throws SQLException {
		
		String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
		Connection conn = DriverManager.getConnection (url, "root", "");
		stmt = conn.prepareStatement("insert into e_elec_comp_phone " +
				"(name, vg_url) values (?, ?)");
		
		browser = new Browser(parent, SWT.None);
		browser.addProgressListener(this);
		loadPage();
	}
	
	private void loadPage() {

		if (pageCount++ < 1000) {
			System.out.println("Page count: " + pageCount);
			browser.setUrl(url + pageCount + "_30");
		}
	}
	
	@Override
	public void completed(ProgressEvent arg0) {
		/*browser.evaluate("window.document.evaluate(" +
				"'//*[@id=\"type_product_up\"]/div/div[1]/div/div[1]/a')");*/
		/*new Thread() {
			public void run() {
				browser.getDisplay().syncExec(new Runnable() {
					
					@Override
					public void run() {
						try {
							processOnePage();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
				});
				
			}
		}.start();*/
		try {
			processOnePage();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		loadPage();
	}
	
	@Override
	public void changed(ProgressEvent arg0) {
		
	}
	
	private void processOnePage() throws SQLException {
		/*try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
		//alert("closed", "!window.closed");
		//alert("document", "window.document");
		//alert("type_product_up", "window.document.getElementById('type_product')");
		//alert("firstChild", "window.document.getElementById('type_product_up').firstChild");
		String firstItem = "window.document.getElementById('type_product')" +
				".firstChild.firstChild.nextSibling";
		//alert("firstItem", firstItem + ".innerHTML");
		//alert("firstItem href", firstItem + ".firstChild.nextSibling.firstChild.nextSibling.firstChild.href");

		//browser.evaluate("fetchLinks = new Object();");
		//browser.evaluate("fetchIndex = 0;");
		browser.evaluate("fetchItem = " + firstItem + ";");
		
		while (true) {
			boolean hasMore = (boolean) browser.evaluate("return fetchItem.firstChild != null");
			if (!hasMore) {
				break;
			}
			//browser.evaluate("fetchLinks[fetchIndex] = fetchItem;");
			String url = (String) browser.evaluate("return fetchItem.firstChild.nextSibling." +
				"firstChild.nextSibling.firstChild.href");
			//browser.evaluate("alert(fetchLinks[fetchIndex]);");
			//System.out.println(url);

			String name = (String) browser.evaluate("return $(fetchItem.firstChild.nextSibling." +
				"firstChild.nextSibling.nextSibling.nextSibling.firstChild).text()");
			//browser.evaluate("alert(fetchLinks[fetchIndex]);");
			//System.out.println(name);
			
			//insert db
			stmt.setString(1, name);
			stmt.setString(2, url);
			stmt.executeUpdate();
			
			browser.evaluate("fetchItem = fetchItem.nextSibling;");
			//browser.evaluate("alert(fetchItem != null)");
			/*boolean hasMore = (boolean) browser.evaluate("return fetchItem != null");
			if (!hasMore) {
				break;
			}*/
			browser.evaluate("fetchItem = fetchItem.nextSibling;");
			//browser.evaluate("alert(fetchItem != null)");
			//browser.evaluate("alert('next: ' + fetchItem);");
			/*hasMore = (boolean) browser.evaluate("return fetchItem != null");
			if (!hasMore) {
				break;
			}*/
		}
	}
}
