package com.jinnova.biang.siteextractor.base;

import java.util.Map.Entry;

import org.eclipse.swt.browser.Browser;

import com.google.gson.JsonElement;
import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.ento.EntoSpec;

public class FetcherBase {

	public boolean debugging;
	
	public Browser browser;

	public Ento ento;

	public EntoSpec spec;
	
	private Object entoUpdateStatement = new Object();
	
	public FetcherBase() {
		
		try {
			Class.forName ("com.mysql.jdbc.Driver").newInstance ();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	public void alert(String name, String script) {
		browser.evaluate("alert('" + name + ": ' + " + script + ")");
		//Object o = browser.evaluate(script);
		//System.out.println(name + ": " + o);
	}
	
	public void updateEnto() throws EntoPersistentException {
		try {
			ento.setUpdateBy("fetcher");
			System.out.println("Fetch stat: " + ento.getFieldValue("fetch_stat"));
			entoUpdateStatement = spec.update(ento, entoUpdateStatement);
		} catch (EntoPersistentException e) {
			System.out.println("*****SQLTypeError: " + e.getMessage());
			for (Entry<String, JsonElement> entry :ento.getAllFields().entrySet()) {
				if ("fetch_stat".equals(entry.getKey())) {
					ento.setFieldValue(entry.getKey(), "SQLTypeError");
				} else if (!"vg_url".equals(entry.getKey())) {
					ento.setFieldValue(entry.getKey(), (String) null);
				}
			}
			entoUpdateStatement = spec.update(ento, entoUpdateStatement);
		}
	}

}
