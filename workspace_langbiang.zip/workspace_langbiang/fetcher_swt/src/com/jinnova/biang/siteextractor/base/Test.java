package com.jinnova.biang.siteextractor.base;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*String deviceMame = "Điện thoại Samsung Galaxy S II HD LTE (Samsung Galaxy S 2/ Samsung Galaxy S II HD LTE SHV-E120S) Black - Thông số kỹ thuật";
		System.out.println(deviceMame);
		deviceMame = deviceMame.substring("Điện thoại ".length());
		System.out.println(deviceMame);
		deviceMame = deviceMame.substring(0, deviceMame.length() - " - Thông số kỹ thuật".length());
		System.out.println(deviceMame);
		if (deviceMame.indexOf("Black") >= 0) {
			deviceMame = deviceMame.substring(0, deviceMame.indexOf("Black"));
			System.out.println(deviceMame);
		}*/
		
		final Pattern cpuFreg1 = Pattern.compile("[\\d|\\.]+ *GHz");
		String s = "1.5 GHz Dual-Core";
		Matcher m = cpuFreg1.matcher(s);
		m.find();
		String f = s.substring(m.start(), m.end());
		final Pattern cpuFreg2 = Pattern.compile("[\\d|\\.]+");
		m = cpuFreg2.matcher(f);
		m.find();
		f = f.substring(m.start(), m.end());
		System.out.println(f);
	}

}
