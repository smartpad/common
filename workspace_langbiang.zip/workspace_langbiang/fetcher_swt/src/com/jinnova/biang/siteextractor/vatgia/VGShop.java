package com.jinnova.biang.siteextractor.vatgia;

import java.util.List;

import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.ento.EntoSpec;
import com.jinnova.biang.ento.EntoSpecField;
import com.jinnova.biang.siteextractor.base.FlowSupport;

public class VGShop extends FlowSupport {
	
	private static final String URL_PREFIX = "http://vatgia.com";
	
	private String baseUrl;
	
	private int page;
	private int maxPage;

	private EntoSpec bizSpec;

	private EntoSpec catSpec;

	private List<Ento> allCats;

	private Ento currentCat;

	private EntoSpecField idField;
	
	public VGShop() {
//		baseUrl = "http://vatgia.com/home/shop.php?&view=list&iCat=433&page=";
//		maxPage = 103;
		
//		baseUrl = "http://vatgia.com/home/shop.php?view=list&iCat=1280&page=";
//		maxPage = 73;
	}
	
	private void nextCat() {
		currentCat = allCats.remove(0);
		if (currentCat != null) {
			String currentPageString = currentCat.getFieldValue("page");
			if ("-1".equals(currentPageString)) {
				nextCat();
				return;
			}
			baseUrl = currentCat.getFieldValue("vg_id");
			maxPage = Integer.valueOf(currentCat.getFieldValue("count")) / 30 + 1;
			if (currentPageString == null) {
				page = 0;
			} else {
				page = Integer.valueOf(currentPageString);
			}
		}
	}

	@Override
	public void setup() {
		bizSpec = EntoManager.instance.getSpec("biz");
		catSpec = EntoManager.instance.getSpec("vg_cat");
		
		idField = bizSpec.getField("vg_id");
		bizSpec.createIndex(idField);
		allCats = catSpec.getAllEntos();
		
		nextCat();
	}

	@Override
	protected String nextUrl() {
		if (currentCat == null) {
			return null;
		}
		
		currentCat.setFieldValue("page", String.valueOf(page));
		try {
			catSpec.update(currentCat);
		} catch (EntoPersistentException e) {
			e.printStackTrace();
		}
		
		if (page >= maxPage) {
			nextCat();
			return nextUrl();
		}
		
		page++;
		String url = URL_PREFIX + baseUrl + "&page=" + page;
		return url;
	}

	@Override
	protected void processOnePage() {
		
		browser.evaluate("fetchingRows = $('table.shop_table tbody').children('tr')"); //rows
		browser.evaluate("rowIndex = 0");
		
		while (true) {

			browser.evaluate("rowIndex++");
			boolean rowExist = (Boolean) browser.evaluate("return fetchingRows[rowIndex] != null");
			if (!rowExist) {
				break;
			}
			
			StringBuffer printing = new StringBuffer(); 
			browser.evaluate("fetchingCells = $(fetchingRows[rowIndex]).children('td')"); //tr
			String s = evaluate("$(fetchingCells[1]).find('a').attr('href')");
			if (startsWith(s, "/")) {
				s = substring(s, 1);
			}
			
			Ento oneBiz = bizSpec.getEnto(idField, s);
			if (oneBiz != null) {
				continue;
			}
			oneBiz = bizSpec.createEnto(null);
			oneBiz.setFieldValue("vg_id", s);
			printing.append(s);
			
			s = evaluate("$(fetchingCells[1]).find('a img').attr('src')");
			if (!"http://static.vatgia.com/css/multi_css_v2/standard/no_photo_x_small.gif".equals(s)) {
				oneBiz.setFieldValue("vg_logo", s);
			}
			
			s = evaluate("$(fetchingCells[2]).find('div.company_name a').text()");
			oneBiz.setFieldValue("name", s);
			printing.append(" " + s);
			
			s = evaluate("$(fetchingCells[2]).find('div.address b').text()");
			s = replace(s, "(");
			s = replace(s, ")");
			oneBiz.setFieldValue("city", s);
			printing.append(" " + s);
			
			s = evaluate("$(fetchingCells[2]).find('div.address').children().remove().end().text()");
			oneBiz.setFieldValue("address", s);
			printing.append(" " + s);

			s = evaluate("$(fetchingCells[3]).find('div.phone').text()");
			s = replace(s, "Điện thoại");
			s = replace(s, ":");
			s = trim(s);
			oneBiz.setFieldValue("phone", split(s, "[/|,]"));
			printing.append(" " + oneBiz.getFieldValueSerialized("phone"));
			
			s = evaluate("$(fetchingCells[3]).find('div.fax').text()");
			s = replace(s, "Fax");
			s = replace(s, ":");
			oneBiz.setFieldValue("fax", s);
			printing.append(" " + s);
			
			s = evaluate("$(fetchingCells[3]).find('div.website a').attr('href')");
			oneBiz.setFieldValue("website", s);
			printing.append(" " + s);
			
			s = evaluate("$(fetchingCells[3]).find('div.yahoo a').attr('href')");
			s = replace(s, "ymsgr:sendim?");
			oneBiz.setFieldValue("yahoo", s);
			printing.append(" " + s);
			
			System.out.println(printing.toString());
			
			try {
				bizSpec.insert(oneBiz);
			} catch (EntoPersistentException e) {
				System.out.print("EntoPersistentException: " + e.getMessage());
			}
		}
	}

	@Override
	protected void setItemFetchStat(String s) {
		
	}
	
}