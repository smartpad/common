package com.jinnova.biang.siteextractor.vatgia.mobile;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.swt.browser.ProgressListener;

import com.jinnova.biang.siteextractor.base.CombinedExtractor;
import com.jinnova.biang.siteextractor.base.DetailBase;
import com.jinnova.biang.siteextractor.base.ExtractNameSupport;
import com.jinnova.biang.siteextractor.base.Extractor;
import com.jinnova.biang.siteextractor.base.MultiChoiceExtractor;
import com.jinnova.biang.siteextractor.base.MultivalueExtractor;
import com.jinnova.biang.siteextractor.base.NumberExtractor;
import com.jinnova.biang.siteextractor.base.SimpleExtractor;

public class VatGiaLaptopDetails extends DetailBase implements ProgressListener {
	
	private int fieldIndex;

	@Override
	public String getCatId() {
		return "elec_comp_laptop";
	}

	@Override
	public int getMinFieldCount() {
		return 15;
	}
	
	public void setup() {
		
		extractors = new HashMap<>();
		extractors.put("Hãng sản xuất", new SimpleExtractor(this, "manu", fieldIndex++));
		/*SimpleExtractor se = new SimpleExtractor(this, "screen", fieldIndex++);
		se.nameMasks.put("capacitive", "Capacitive");
		extractors.put("Loại màn hình cảm ứng", se);
		extractors.put("Công nghệ màn hình", new SimpleExtractor(this, "screen_tech", fieldIndex++));*/
		
		extractors.put("Độ lớn màn hình", 
				new NumberExtractor(this, new String[] {"screen_dia"}, fieldIndex++, " *[i|I][n|N][c|C][h|H]"));
		CombinedExtractor ce = new CombinedExtractor();
		ce.extractors.add(new NumberExtractor(this, new String[] {"screen_width", "screen_height"}, fieldIndex++));

		//final Pattern screenTechPattern = Pattern.compile(".*\\(d+ *[x|X] *d+\\).*");
		//final Pattern screenTechPattern = Pattern.compile("\\(");
		ce.extractors.add(new Extractor() {
			
			@Override
			public void extract(String s) {
				/*Matcher m = screenTechPattern.matcher(s);
				m.matches();
				s = s.subSequence(0, m.start()).toString();*/
				s = s.trim();
				s = s.substring(0, s.indexOf('('));
				SimpleExtractor simpleEx = new SimpleExtractor(VatGiaLaptopDetails.this, "screen_tech", fieldIndex++);
				simpleEx.nameMasks.put("hd", null);
				simpleEx.extract(s);
				//ento.setFieldValue("screen_tech", s);
				//System.out.println("Field " + fieldIndex++ + ": screen_tech=" + s);
			}
		});
		extractors.put("Độ phân giải", ce);
		/*extractors.put("", new Extractor() {
			@Override
			public void extract(String s) {
				int cores;
				s = s.toLowerCase();
				if (s.contains("single core")) {
					cores = 1;
				} else if (s.contains("dual core")) {
					cores = 2;
				} else if (s.contains("quad core")) {
					cores = 4;
				} else {
					throw new RuntimeException(s);
				}
				ento.setFieldValue("cpu_cores", String.valueOf(cores));
			}
		});*/
		
		extractors.put("Motherboard Chipset", new SimpleExtractor(this, "chipset", fieldIndex++));
		extractors.put("Loại CPU", new SimpleExtractor(this, "cpu_name", fieldIndex++));
		
		final String ghz = "[G|g|M|m][h|H][z|Z]";
		final Pattern cpuFreg = Pattern.compile("[\\d|\\.]+ *" + ghz);
		//final Pattern cpuFregMHz = Pattern.compile("[\\d|\\.]+ *MHz");
		final Pattern numberPattern = Pattern.compile(NumberExtractor.NUMBER_REGEX);
		Extractor frequecyEx = new Extractor() {
			@Override
			public void extract(final String s) {
				if (s == null || s.trim().isEmpty() || s.trim().equals("-")) {
					return;
				}
				Matcher m = cpuFreg.matcher(s);
				if (!m.find()) {
					//throw new RuntimeException("cpu freq invalid: " + s);
					return;
				}
				String f = s.substring(m.start(), m.end());
				m = numberPattern.matcher(f);
				m.find();
				f = f.substring(m.start(), m.end());
				String unit;
				if (s.toUpperCase().contains("GHZ")) {
					unit = "GHz";
				} else {
					unit = "MHz";
				}
				ento.setFieldValue("cpu_freq", f);
				System.out.println("cpu_freq=" + f);
				ento.setFieldValue("cpu_freq_unit", unit);
				System.out.println("cpu_freq_unit=" + unit);
			}
		};
		ce = new CombinedExtractor();
		ce.extractors.add(frequecyEx);
		Extractor ex = new Extractor() {
			
			@Override
			public void extract(String s) {
				s = s.substring(s.indexOf('(') + 1, s.indexOf(')'));
				ento.setFieldValue("cpu_extra", s);
				System.out.println("Field " + fieldIndex++ + ": cpu_extra="  + s);
			}
		};
		ce.extractors.add(ex);
		extractors.put("Tốc độ máy", ce);
		
		extractors.put("Memory Type", new SimpleExtractor(this, "mem_ram_type", fieldIndex++));
		NumberExtractor ne = new NumberExtractor(this, "mem_ram", fieldIndex++);
		ne.failOnMoreNumbers = false;
		extractors.put("Dung lượng Memory", ne);
		
		extractors.put("Loại ổ cứng", new SimpleExtractor(this, "mem_internal_type", fieldIndex++));
		extractors.put("Dung lượng HDD", new NumberExtractor(this, "mem_internal", fieldIndex++));
		extractors.put("Dung lượng SSD", new NumberExtractor(this, "mem_internal_ssd", fieldIndex++));
		extractors.put("Số vòng quay của HDD", new NumberExtractor(this, "mem_hdd_rpm", fieldIndex++));
		extractors.put("Loại ổ đĩa quang", new SimpleExtractor(this, "cddrive", fieldIndex++));

		extractors.put("Video Chipset", new SimpleExtractor(this, "gpu_name", fieldIndex++));
		extractors.put("Graphic Memory", new SimpleExtractor(this, "gpu_ram", fieldIndex++));
		
		extractors.put("LAN", new SimpleExtractor(this, "network_wired", fieldIndex++));
		extractors.put("Wifi", new SimpleExtractor(this, "network_wifi", fieldIndex++));
		extractors.put("Chuột", new MultivalueExtractor(this, "pointing_devices", fieldIndex++));
		extractors.put("OS", new SimpleExtractor(this, "os", fieldIndex++));
		
		ExtractNameSupport mce = new MultiChoiceExtractor(this, "", fieldIndex++);
		mce.nameMasks.put("bảo_mật_bằng_dấu_vân_tay", "finger_auth");
		mce.nameMasks.put("hdmi", "connectport_hdmi");
		mce.nameMasks.put("vga_out", "connectport_vga");
		mce.nameMasks.put("rj_11", "connectport_rj11");
		mce.nameMasks.put("bluetooth", "network_bluetooth");
		mce.nameMasks.put("nhận_dạng_khuôn_mặt", "face_auth");
		mce.nameMasks.put("màn_hình_cảm_ứng", "touchscreen");
		mce.ignores.add("camera");
		mce.ignores.add("microphone");
		mce.ignores.add("headphone");
		extractors.put("Tính năng khác", mce);
		
		/*MultiHandlerExtractor me = new MultiHandlerExtractor();
		NumberExtractor ne = new NumberExtractor(this, "bt_version", fieldIndex++);
		me.extractors.put("bluetooth", ne);
		SimpleExtractor se = new SimpleExtractor(this, "gps_integrated", fieldIndex++);
		se.nameMasks.put("gps", "1");
		me.extractors.put("gps", se);
		extractors.put("Kết nối không dây khác", me);*/
		
		extractors.put("Cổng USB", new SimpleExtractor(this, "usb_ports", fieldIndex++));
		//final Pattern usbCountPattern = Pattern.compile("d+ *[x|X] .*[d|\\.]");
		//final Pattern intPattern = Pattern.compile("d+");
		/*extractors.put("Cổng USB", new Extractor() {
			
			@Override
			public void extract(String s) {
				try {
					Matcher m = usbCountPattern.matcher(s);
					if (m.find()) {
						m = numberPattern.matcher(s);
						m.find();
						String count = s.substring(m.start(), m.end());
						m.find();
						String version = s.substring(m.start(), m.end());
						ento.setFieldValue("usb_count", count);
						ento.setFieldValue("usb_version", version);
						System.out.println("Field " + fieldIndex++ + ": use_count=" + count + ", usb_version=" + version);
					} else {
						m = numberPattern.matcher(s);
						if (!m.find()) {
							return;
						}
						String version = s.substring(m.start(), m.end());
						ento.setFieldValue("usb_version", version);
						System.out.println("Field " + fieldIndex++ + ", usb_version=" + version);
					}
				} catch (RuntimeException re) {
					re.printStackTrace();
					throw re;
				}
			}
		});*/
		
		//extractors.put("Loại Pin sử dụng (Battery Type)", new SimpleExtractor(this, "battery_type", fieldIndex++));
		//extractors.put("Dung lượng pin", new NumberExtractor(this, "battery_capa", fieldIndex++));
		extractors.put("Battery", new NumberExtractor(this, "battery_use", fieldIndex++));
		ne = new NumberExtractor(this, new String[] {"size_width", "size_height", "size_thick"}, fieldIndex++);
		ne.failOnLessNumbers = false;
		extractors.put("Kích cỡ (mm)", ne);
		ne = new NumberExtractor(this, "weight", fieldIndex++);
		ne.multiplier = new BigDecimal(1000);
		extractors.put("Trọng lượng", ne);
		
		SimpleExtractor se = new SimpleExtractor(this, "card_reader", fieldIndex++);
		se.nameMasks.put("card_reader", "1");
		extractors.put("Cổng đọc Card", se);

		se = new SimpleExtractor(this, "feature_others", fieldIndex++);
		se.innerHTML = true;
		extractors.put("Tính năng đặc biệt", se);
		se = new SimpleExtractor(this, "manu_url", fieldIndex++);
		se.href = true;
		extractors.put("Website", se);
		
		//extractors.put(3, new SimpleExtractor(this, "style", 3));
		
		/*extractors.put(12, new SimpleExtractor(this, "os_name", 12));
		extractors.put(13, new SimpleExtractor(this, "address_book", 13));
		extractors.put(14, new SimpleExtractor(this, "call_diary", 14));
		mce = new MultiChoiceExtractor(this, "messaging_", 15);
		mce.nameMasks.put("instant_messaging", "im");
		extractors.put(15, mce);
		mce = new MultiChoiceExtractor(this, "ringtone_", 16);
		mce.nameMasks.put("đa_âm_sắc", "multitone");
		//mce.ignores.add("đơn_âm");
		mce.skipUnknowns = true;
		extractors.put(16, mce);
		mce = new MultiChoiceExtractor(this, "", 17);
		mce.nameMasks.put("Có", "vibration");
		extractors.put(17, mce);
		
		NumberExtractor ne = new NumberExtractor(this, new String[] {"sim_count"}, 18, " *[s|S][i|I][m|M]");
		ne.failOnMoreNumbers = false;
		extractors.put(18, ne);
		
		mce = new MultiChoiceExtractor(this, "mem_ext_", 19);
		mce.ignores.add("không_hỗ_trợ");
		//mce.ignores.add("gprs");
		mce.nameMasks.put("memory_stick_micro", "ms_micro");
		extractors.put(19, mce);
		extractors.put(22, new NumberExtractor(this, "camera_res", 22));
		mce = new MultiChoiceExtractor(this, "", 23);
		mce.nameMasks.put("3_5_mm_audio_output_jack", "audio_jack_35");
		mce.nameMasks.put("kết_nối_gps", "gps_integrated");
		mce.nameMasks.put("loa_ngoài", "loud_speaker");
		mce.nameMasks.put("loa_thoại", "loud_speaker");
		mce.nameMasks.put("đèn_flash", "camera_flash");
		mce.nameMasks.put("video_720p", "video_record_720p");
		mce.nameMasks.put("video_1080p", "video_record_1080p");
		mce.nameMasks.put("ghi_âm", "voice_recorder");
		mce.nameMasks.put("kết_nối_tv", "tv_out");
		mce.nameMasks.put("radio", "radio");
		mce.skipUnknowns = true;
		extractors.put(23, mce);

		//other features
		CombinedExtractor ce = new CombinedExtractor();
		mce = new MultiChoiceExtractor(this, "", 24);
		mce.nameMasks.put("proximity_sensor", "sensor_proxi");
		mce.nameMasks.put("accelerometer_sensor", "sensor_accel");
		mce.nameMasks.put("digital_compass", "sensor_compass");
		mce.nameMasks.put("gyro_sensor", "sensor_gyro");
		mce.skipUnknowns = true;
		ce.extractors.add(mce);
		mce = new MultivalueExtractor(this, "feature_others", 24);
		ce.extractors.add(mce);
		extractors.put(24, ce);
		
		extractors.put(25, new MultivalueExtractor(this, "colors", 25));
		ce = new CombinedExtractor();
		ne = new NumberExtractor(this, "battery_capa", 26);
		ne.failOnLessNumbers = false;
		ce.extractors.add(ne);
		SimpleExtractor se = new SimpleExtractor(this, "battery_type", 26);
		se.nameMasks.put("li-ion", "Li-Ion");
		ce.extractors.add(se);
		extractors.put(26, ce);
		
		extractors.put(27, new NumberExtractor(this, "battery_voice", 27));
		extractors.put(28, new NumberExtractor(this, "battery_standby", 28));
		extractors.put(29, new NumberExtractor(this, "weight", 29));
		extractors.put(30, new NumberExtractor(this, new String[] {"size_height", "size_width", "size_thick"}, 30));*/
	}
}
