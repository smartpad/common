package com.jinnova.biang.siteextractor.base;

import java.util.LinkedList;
import java.util.StringTokenizer;

public class MultivalueExtractor extends ExtractNameSupport implements Extractor {
	
	private final String additionalSeparators;
	
	public MultivalueExtractor(FetcherBase fetcher, String fieldName, int fieldIndex) {
		this(fetcher, fieldName, fieldIndex, "");
	}
	
	public MultivalueExtractor(FetcherBase fetcher, String fieldName, int fieldIndex, String additionalSeparators) {
		super(fetcher, fieldName, fieldIndex);
		this.additionalSeparators = additionalSeparators;
		//this.skipUnknowns = false;
	}
	
	@Override
	public void extract(String s) {
		
		StringTokenizer tokens = new StringTokenizer(s, "•\n" + additionalSeparators);
		LinkedList<String> values = new LinkedList<>();
		while (tokens.hasMoreTokens()) {
			String one = tokens.nextToken();
			one = one.trim();
			//one = one.replaceAll("\n", "");
			String normalOne = normalizeAsString(one);
			if (normalOne == null) {
				continue;
			}
			values.add(one);
		}
		try {
			fetcher.ento.setFieldValue(fieldName, values);
			//if (fetcher.debugging) {
				System.out.println("Field " + fieldIndex + ": " + fieldName + "=" + fetcher.ento.getFieldValueSerialized(fieldName));
			//}
		} catch (RuntimeException e) {
			throw e;
		}
	}

}
