package com.jinnova.biang.siteextractor.base;

import java.util.HashMap;
import java.util.StringTokenizer;

public class MultiHandlerExtractor implements Extractor {
	
	private final String additionalSeparators;
	
	public final HashMap<String, Extractor> extractors = new HashMap<>();
	
	public MultiHandlerExtractor() {
		this("");
	}
	
	public MultiHandlerExtractor(String additionalSeparators) {
		this.additionalSeparators = additionalSeparators;
	}
	
	@Override
	public void extract(String s) {
		
		StringTokenizer tokens = new StringTokenizer(s, "•\n" + additionalSeparators);
		while (tokens.hasMoreTokens()) {
			String one = tokens.nextToken();
			one = one.trim();
			for (String key : extractors.keySet()) {
				if (one.toLowerCase().contains(key.toLowerCase())) {
					Extractor ex = extractors.get(key);
					ex.extract(one);
				}
			}
			
		}
	}

}
