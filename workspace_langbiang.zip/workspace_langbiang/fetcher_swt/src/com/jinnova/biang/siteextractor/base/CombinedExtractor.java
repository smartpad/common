package com.jinnova.biang.siteextractor.base;

import java.util.LinkedList;

public class CombinedExtractor implements Extractor {
	
	public final LinkedList<Extractor> extractors = new LinkedList<>();
	
	/*public CombinedExtractor(Extractor[] extractors) {
		for (int i = 0; i < extractors.length; i++) {
			this.extractors.add(extractors[i]);
		}
	}*/

	@Override
	public void extract(String s) {
		for (Extractor ex : extractors) {
			ex.extract(s);
		}
	}

}
