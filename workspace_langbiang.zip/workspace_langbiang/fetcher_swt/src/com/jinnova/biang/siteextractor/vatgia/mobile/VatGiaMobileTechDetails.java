package com.jinnova.biang.siteextractor.vatgia.mobile;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.browser.ProgressListener;
import org.eclipse.swt.widgets.Composite;

import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.siteextractor.base.CombinedExtractor;
import com.jinnova.biang.siteextractor.base.ExtractNameSupport;
import com.jinnova.biang.siteextractor.base.Extractor;
import com.jinnova.biang.siteextractor.base.FetcherBase;
import com.jinnova.biang.siteextractor.base.MultiChoiceExtractor;
import com.jinnova.biang.siteextractor.base.MultivalueExtractor;
import com.jinnova.biang.siteextractor.base.NumberExtractor;
import com.jinnova.biang.siteextractor.base.SimpleExtractor;

public class VatGiaMobileTechDetails extends FetcherBase implements ProgressListener {
	
	private static final String FIRST_ROW = "window.document.getElementById('detail_product_technical')" +
				".firstChild.nextSibling.nextSibling.nextSibling.nextSibling.nextSibling" +
				".firstChild.nextSibling.firstChild.nextSibling";

	//private PreparedStatement insert;
	
	private int itemCount = 1;
	private int itemCountSuccess = 0;

	//private ResultSet rs;

	//private String origUrl;

	private Iterator<Ento> iterator;

	//private String actualValuePath;

	//private HashMap<Integer, String>  customRowMovers;

	private HashMap<Integer, String>  fieldNames;

	private HashMap<Integer, Extractor>  extractors;

	//private String rowMover;

	private String debuggingUrl;
	
	private long loadStart, loadEnd, fetchStart, fetchEnd;

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 * @throws EntoPersistentException 
	 */
	public void createPartControl(Composite parent) throws EntoPersistentException {
		
		//String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
		//Connection conn = DriverManager.getConnection (url, "root", "");
		//Statement select = conn.createStatement();
		//rs = select.executeQuery("select * from e_elec_comp_phone where fetched = false");
		/*insert = conn.prepareStatement("insert into e_elec_comp_phone " +
				"(name, vg_url) values (?, ?)");*/
		
		browser = new Browser(parent, SWT.None);
		browser.addProgressListener(this);
		spec = EntoManager.instance.getSpec("elec_comp_phone");
		iterator = spec.getAllEntos().iterator();
		//debuggingUrl = "http://vatgia.com/438/1175748/thong_so_ky_thuat/samsung-i9100-galaxy-s-ii-galaxy-s-2-16gb-black.html";
		debugging = debuggingUrl != null;
		setup();
		loadPage();
	}
	
	private void loadPage() throws EntoPersistentException {
		
		/*if (!rs.next()) {
			return;
		}*/
		
		if (ento != null) {
			updateEnto();
		}
		
		do {
			if (!iterator.hasNext()) {
				return;
			}
			ento = iterator.next();
			if (ento.getFieldValue("fetch_stat") == null) {
				break;
			}
		} while (true);
		
		String url = debuggingUrl;
		if (url == null) {
			//String url = rs.getString("vg_url");
			url = ento.getFieldValue("vg_url");
			//origUrl = url;
			int i = url.indexOf("/");
			i = url.indexOf("/", i + 1);
			i = url.indexOf("/", i + 1);
			i = url.indexOf("/", i + 1);
			i = url.indexOf("/", i + 1);
			url = url.substring(0, i) + "/thong_so_ky_thuat" + url.substring(i);
		}
		fetchEnd = System.currentTimeMillis();
		System.out.println(itemCount++ + " (" + itemCountSuccess + "): " + 
				(loadEnd - loadStart) + "/" + (fetchEnd - fetchStart) + ": " + url);
		loadStart = System.currentTimeMillis();
		ento.setFieldValue("fetch_stat", "processed");
		browser.setUrl(url);
	}
	
	@Override
	public void completed(ProgressEvent arg0) {
		loadEnd = System.currentTimeMillis();
		fetchStart = System.currentTimeMillis();
		try {
			processOnePage();
			if (debuggingUrl != null) {
				return;
			}
			loadPage();
		} catch (EntoPersistentException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void changed(ProgressEvent arg0) {
		
	}
	
	private void processOnePage() {
		
		String deviceMame;
		try {
			deviceMame = (String) browser.evaluate("return $(window.document.getElementById('header_navigate_extend')).text()");
		} catch (SWTException e) {
			ento.setFieldValue("fetch_stat", "error_dom_first");
			System.out.println("*****SWTException at first field: deviceName" + e.getMessage());
			return;
		}
		//Điện thoại Samsung Galaxy S II HD LTE (Samsung Galaxy S 2/ Samsung Galaxy S II HD LTE SHV-E120S) Black - Thông số kỹ thuật
		System.out.println(deviceMame);
		//deviceMame = deviceMame.substring("Điện thoại ".length());
		//deviceMame = deviceMame.substring(0, deviceMame.length() - " - Thông số kỹ thuật".length());
		ento.setFieldValue("brand", deviceMame);
		
		browser.evaluate("fetchingImages = window.document.getElementById('detail_product_picture_thumbnail')");
		boolean thumbsExist = (Boolean) browser.evaluate("return fetchingImages != null");
		if (thumbsExist) {
			//browser.evaluate("fetchingImages = fetchingImages.firstChild.firstChild.nextSibling.firstChild"); //got table
			browser.evaluate("fetchingImages = fetchingImages.getElementsByTagName('table')[0]");
			//browser.evaluate("alert(fetchingImages)");
			browser.evaluate("fetchingImages = fetchingImages.rows[0].cells[0]");
			//browser.evaluate("alert(fetchingImages)");
			//browser.evaluate("fetchingImages = fetchingImages.firstChild.firstChild.firstChild.nextSibling"); //got first td
			//browser.evaluate("alert(fetchingImages.firstChild.nextSibling)");
			LinkedList<String> imageUrls = new LinkedList<>();
			while (true) {
				String oneImg = (String) browser.evaluate("return fetchingImages.firstChild.nextSibling.href");
				System.out.println("Image: " + oneImg);
				imageUrls.add(oneImg);
				browser.evaluate("fetchingImages = fetchingImages.nextSibling.nextSibling");
				//browser.evaluate("alert(fetchingImages)");
				boolean b = (Boolean) browser.evaluate("return fetchingImages == null");
				if (b) {
					break;
				}
			}
			ento.setFieldValue("image_origs", imageUrls);
		} else {
			browser.evaluate("fetchingImages = window.document.getElementById('detail_product_picture_main')");
			String oneImageUrl = (String) browser.evaluate("return fetchingImages.firstChild.nextSibling.nextSibling.href");
			System.out.println("Image: " + oneImageUrl);
			ento.setFieldValue("image_origs", oneImageUrl);
		}
		
		int fieldIndex = 0;
		browser.evaluate("fetchingRow = " + FIRST_ROW);
		//int fieldSkipCount = 0;
		int extractedFieldCount = 0;
		while (true) {
			fieldIndex++;
			if (fieldIndex > 30) {
				break;
			}
			
			try {
				browser.evaluate("fetchingNameElement=fetchingRow.firstChild");
				browser.evaluate("if (Object.prototype.toString.call(fetchingNameElement).slice(8, -1) == 'Text') " +
						"fetchingNameElement=fetchingNameElement.nextSibling");
				String currentFieldName = (String) browser.evaluate("return $(fetchingNameElement).text()");
				currentFieldName = currentFieldName.trim();
				if (debugging) {
					System.out.println("field " + fieldIndex + " encountered name: " + currentFieldName);
				}
				if (fieldNames.containsKey(fieldIndex)) {
					if (!currentFieldName.toLowerCase().startsWith(fieldNames.get(fieldIndex).toLowerCase())) {
						//missing one field
						System.out.println("missing field " + fieldIndex + " " + fieldNames.get(fieldIndex) + 
								", encountered: " + currentFieldName + ": skipped");
						continue;
					}
				}
			} catch (SWTException e) {
				ento.setFieldValue("fetch_stat", "error_dom_name" + fieldIndex);
				System.out.println("*****SWTException at name of field " + fieldIndex + ": " + e.getMessage());
				return;
			}
			String value;
			try {
				//.firstChild.nextSibling.nextSibling.nextSibling
				//browser.evaluate("alert(fetchingRow.tagName)");
				browser.evaluate("fetchingValueElement = fetchingRow.firstChild");
				//browser.evaluate("alert(fetchingValueElement.tagName)");
				
				browser.evaluate("if (Object.prototype.toString.call(fetchingValueElement).slice(8, -1) == 'Text') " +
						"fetchingValueElement=fetchingValueElement.nextSibling");
				//browser.evaluate("alert(fetchingValueElement.tagName + ': ' + $(fetchingValueElement).text())");
				
				browser.evaluate("fetchingValueElement = fetchingValueElement.nextSibling");
				//browser.evaluate("alert(fetchingValueElement.tagName)");
				
				browser.evaluate("if (Object.prototype.toString.call(fetchingValueElement).slice(8, -1) == 'Text') " +
						"fetchingValueElement=fetchingValueElement.nextSibling");
				//browser.evaluate("alert(fetchingValueElement.tagName)");
				
				value = (String) browser.evaluate("return $(fetchingValueElement).text()");
				if (debugging) {
					System.out.println("field " + fieldIndex + " value: " + value);
				}
			} catch (SWTException e) {
				ento.setFieldValue("fetch_stat", "error_dom_value" + fieldIndex);
				System.out.println("*****SWTException at value of field " + fieldIndex + ": " + e.getMessage());
				//throw e;
				return;
			}
			
			Extractor ext = extractors.get(fieldIndex);
			if (ext != null) {
				try {
					ext.extract(value);
					extractedFieldCount++;
				} catch (RuntimeException e) {
					ento.setFieldValue("fetch_stat", "error_extract_" + fieldIndex);
					System.out.println("*****RuntimeException at field " + fieldIndex + ": " + e.getMessage());
					return;
				}
			}
			
			/*String actualRowMover = customRowMovers.get(fieldIndex);
			if (actualRowMover == null) {
				actualRowMover = rowMover;
			}
			browser.evaluate("fetchingRow = fetchingRow" + actualRowMover);*/
			browser.evaluate("fetchingRow = fetchingRow.nextSibling.nextSibling");
			//browser.evaluate("alert(fetchingRow == null)");
			boolean moreRows;
			//if (fieldIndex < 30) {
				do {
					//System.out.println("fetchingRow script1: " + browser.evaluate("return fetchingRow != null"));
					moreRows = (Boolean) browser.evaluate("return fetchingRow != null");
					if (!moreRows) {
						//System.out.println("Field count is less than expected!");
						//return;
						break;
					}
					boolean sectionTitle = (Boolean) browser.evaluate("return fetchingRow.childNodes.length == 1");
					if (!sectionTitle) {
						browser.evaluate("fetchingNameElement=fetchingRow.firstChild");
						browser.evaluate("if (Object.prototype.toString.call(fetchingNameElement).slice(8, -1) == 'Text') " +
								"fetchingNameElement=fetchingNameElement.nextSibling");
						String currentFieldName = (String) browser.evaluate("return $(fetchingNameElement).text()");
						currentFieldName = currentFieldName.trim();
						if (fieldNames.containsValue(currentFieldName)) {
							break;
						}
					}
					browser.evaluate("fetchingRow = fetchingRow.nextSibling");
				} while (true);
			//}
			if (!moreRows) {
				break;
			}
		}
		
		if (extractedFieldCount < 20) {
			ento.setFieldValue("fetch_stat", "error_field_toofew_" + extractedFieldCount);
			System.out.println("*****Error: " + extractedFieldCount + " < 25 fields");
			return;
		}
		ento.setFieldValue("fetch_stat", "y");
		itemCountSuccess++;
	}
	
	private void setup() {
		
		//String valuePath = ".firstChild.nextSibling.nextSibling.nextSibling";
		//String namePath = ".firstChild.nextSibling";
		//String namePath = ".getElementsByTagName('TD')[0]";
		//rowMover = ".nextSibling.nextSibling";
		
		//HashMap<Integer, String> customValuePaths = new HashMap<>();
		/*customRowMovers = new HashMap<>();
		customRowMovers.put(3, rowMover + ".nextSibling");
		customRowMovers.put(6, rowMover + ".nextSibling");
		customRowMovers.put(8, rowMover + ".nextSibling");
		customRowMovers.put(9, rowMover + ".nextSibling");
		customRowMovers.put(11, rowMover + ".nextSibling");
		customRowMovers.put(12, rowMover + ".nextSibling");
		customRowMovers.put(25, rowMover + ".nextSibling");
		customRowMovers.put(28, rowMover + ".nextSibling");*/
		
		fieldNames = new HashMap<>();
		fieldNames.put(1, "Hãng sản xuất");
		fieldNames.put(2, "Mạng");
		fieldNames.put(3, "Kiểu dáng");
		
		fieldNames.put(4, "Màn hình");
		fieldNames.put(5, "Kích thước màn hình");
		fieldNames.put(6, "Độ phân giải màn hình");
		
		fieldNames.put(7, "Số lượng Cores");
		fieldNames.put(8, "Bộ vi xử lý");
		
		fieldNames.put(9, "Bộ xử lý đồ hoạ");
		fieldNames.put(10, "Bộ nhớ");
		fieldNames.put(11, "RAM");
		fieldNames.put(12, "Hệ điều hành");
		
		fieldNames.put(13, "Sổ địa chỉ");
		fieldNames.put(14, "Nhật ký cuộc gọi");
		fieldNames.put(15, "Tin nhắn");
		
		fieldNames.put(16, "Kiểu chuông");
		fieldNames.put(17, "Rung");
		fieldNames.put(18, "Số sim");
		
		fieldNames.put(19, "Loại thẻ nhớ tích hợp");
		fieldNames.put(20, "Đồng bộ hóa dữ liệu");
		fieldNames.put(21, "Kiểu kết nối");
		
		fieldNames.put(22, "Camera");
		fieldNames.put(23, "Tính năng");
		fieldNames.put(24, "Tính năng khác");
		fieldNames.put(25, "Màu");
		fieldNames.put(26, "Pin");
		fieldNames.put(27, "Thời gian đàm thoại");
		fieldNames.put(28, "Thời gian chờ");
		fieldNames.put(29, "Trọng lượng");
		fieldNames.put(30, "Kích thước");
		
		extractors = new HashMap<>();
		extractors.put(1, new SimpleExtractor(this, "manu", 1));
		ExtractNameSupport mce = new MultiChoiceExtractor(this, "network_", 2);
		mce.ignores.add("hsdpa");
		mce.nameMasks.put("wcdma_2100", "wcdma_2100");
		mce.nameMasks.put("cdma_2000", "cdma_2000");
		extractors.put(2, mce);
		extractors.put(3, new SimpleExtractor(this, "style", 3));
		extractors.put(4, new SimpleExtractor(this, "screen", 4));
		/*extractors.put(5, new Extractor() {
			@Override
			public void extract(String s) {
				s = s.replaceFirst("inch", "");
				ento.setFieldValue("screen_dia", s);
			}
		});*/
		extractors.put(5, new NumberExtractor(this, new String[] {"screen_dia"}, 5, " *[i|I][n|N][c|C][h|H]"));
		extractors.put(6, new NumberExtractor(this, new String[] {"screen_width", "screen_height"}, 6));
		extractors.put(7, new Extractor() {
			@Override
			public void extract(String s) {
				int cores;
				s = s.toLowerCase();
				if (s.contains("single core")) {
					cores = 1;
				} else if (s.contains("dual core")) {
					cores = 2;
				} else if (s.contains("quad core")) {
					cores = 4;
				} else {
					throw new RuntimeException(s);
				}
				ento.setFieldValue("cpu_cores", String.valueOf(cores));
			}
		});
		
		final String ghz = "[G|g|M|m][h|H][z|Z]";
		final Pattern cpuFreg = Pattern.compile("[\\d|\\.]+ *" + ghz);
		//final Pattern cpuFregMHz = Pattern.compile("[\\d|\\.]+ *MHz");
		final Pattern numberPattern = Pattern.compile(NumberExtractor.NUMBER_REGEX);
		extractors.put(8, new Extractor() {
			@Override
			public void extract(String s) {
				if (s == null || s.trim().isEmpty() || s.trim().equals("-")) {
					return;
				}
				Matcher m = cpuFreg.matcher(s);
				if (!m.find()) {
					//throw new RuntimeException("cpu freq invalid: " + s);
					return;
				}
				String f = s.substring(m.start(), m.end());
				m = numberPattern.matcher(f);
				m.find();
				f = f.substring(m.start(), m.end());
				String unit;
				if (s.toUpperCase().contains("GHZ")) {
					unit = "GHz";
				} else {
					unit = "MHz";
				}
				ento.setFieldValue("cpu_freq", f);
				ento.setFieldValue("cpu_freq_unit", unit);
				ento.setFieldValue("cpu_name", s);
			}
		});
		extractors.put(9, new SimpleExtractor(this, "gpu_name", 9));
		extractors.put(10, new NumberExtractor(this, "mem_internal", 10));
		extractors.put(11, new NumberExtractor(this, "mem_ram", 11));
		extractors.put(12, new SimpleExtractor(this, "os_name", 12));
		extractors.put(13, new SimpleExtractor(this, "address_book", 13));
		extractors.put(14, new SimpleExtractor(this, "call_diary", 14));
		mce = new MultiChoiceExtractor(this, "messaging_", 15);
		mce.nameMasks.put("instant_messaging", "im");
		extractors.put(15, mce);
		mce = new MultiChoiceExtractor(this, "ringtone_", 16);
		mce.nameMasks.put("đa_âm_sắc", "multitone");
		//mce.ignores.add("đơn_âm");
		//mce.skipUnknowns = true;
		extractors.put(16, mce);
		mce = new MultiChoiceExtractor(this, "", 17);
		mce.nameMasks.put("Có", "vibration");
		extractors.put(17, mce);
		
		NumberExtractor ne = new NumberExtractor(this, new String[] {"sim_count"}, 18, " *[s|S][i|I][m|M]");
		ne.failOnMoreNumbers = false;
		extractors.put(18, ne);
		
		mce = new MultiChoiceExtractor(this, "mem_ext_", 19);
		mce.ignores.add("không_hỗ_trợ");
		//mce.ignores.add("gprs");
		mce.nameMasks.put("memory_stick_micro", "ms_micro");
		extractors.put(19, mce);
		mce = new MultiChoiceExtractor(this, "connect_", 20);
		mce.ignores.add("wlan");
		mce.nameMasks.put("hsdpa", "hsdpa");
		//mce.skipUnknowns = true;
		extractors.put(20, mce);
		extractors.put(21, new MultiChoiceExtractor(this, "connectport_", 21));
		extractors.put(22, new NumberExtractor(this, "camera_res", 22));
		mce = new MultiChoiceExtractor(this, "", 23);
		mce.nameMasks.put("3_5_mm_audio_output_jack", "audio_jack_35");
		mce.nameMasks.put("kết_nối_gps", "gps_integrated");
		mce.nameMasks.put("loa_ngoài", "loud_speaker");
		mce.nameMasks.put("loa_thoại", "loud_speaker");
		mce.nameMasks.put("đèn_flash", "camera_flash");
		mce.nameMasks.put("video_720p", "video_record_720p");
		mce.nameMasks.put("video_1080p", "video_record_1080p");
		mce.nameMasks.put("ghi_âm", "voice_recorder");
		mce.nameMasks.put("kết_nối_tv", "tv_out");
		mce.nameMasks.put("radio", "radio");
		//mce.skipUnknowns = true;
		extractors.put(23, mce);

		//other features
		CombinedExtractor ce = new CombinedExtractor();
		mce = new MultiChoiceExtractor(this, "", 24);
		mce.nameMasks.put("proximity_sensor", "sensor_proxi");
		mce.nameMasks.put("accelerometer_sensor", "sensor_accel");
		mce.nameMasks.put("digital_compass", "sensor_compass");
		mce.nameMasks.put("gyro_sensor", "sensor_gyro");
		//mce.skipUnknowns = true;
		ce.extractors.add(mce);
		mce = new MultivalueExtractor(this, "feature_others", 24);
		ce.extractors.add(mce);
		extractors.put(24, ce);
		
		extractors.put(25, new MultivalueExtractor(this, "colors", 25));
		ce = new CombinedExtractor();
		ne = new NumberExtractor(this, "battery_capa", 26);
		ne.failOnLessNumbers = false;
		ce.extractors.add(ne);
		SimpleExtractor se = new SimpleExtractor(this, "battery_type", 26);
		se.nameMasks.put("li-ion", "Li-Ion");
		ce.extractors.add(se);
		extractors.put(26, ce);
		
		extractors.put(27, new NumberExtractor(this, "battery_voice", 27));
		extractors.put(28, new NumberExtractor(this, "battery_standby", 28));
		extractors.put(29, new NumberExtractor(this, "weight", 29));
		extractors.put(30, new NumberExtractor(this, new String[] {"size_height", "size_width", "size_thick"}, 30));
	}
}
