package com.jinnova.biang.siteextractor.base;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CpuFrequencyExtractor implements Extractor {
	
	private final String ghz = "[G|g|M|m][h|H][z|Z]";
	private final Pattern cpuFreg = Pattern.compile("[\\d|\\.]+ *" + ghz);
	//private final Pattern cpuFregMHz = Pattern.compile("[\\d|\\.]+ *MHz");
	private final Pattern numberPattern = Pattern.compile(NumberExtractor.NUMBER_REGEX);
	
	private FetcherBase fetcher;
	
	public CpuFrequencyExtractor(FetcherBase fetcher) {
		this.fetcher = fetcher;
	}


	@Override
	public void extract(String s) {
		if (s == null || s.trim().isEmpty() || s.trim().equals("-")) {
			return;
		}
		Matcher m = cpuFreg.matcher(s);
		if (!m.find()) {
			//throw new RuntimeException("cpu freq invalid: " + s);
			return;
		}
		String f = s.substring(m.start(), m.end());
		m = numberPattern.matcher(f);
		m.find();
		f = f.substring(m.start(), m.end());
		String unit;
		if (s.toUpperCase().contains("GHZ")) {
			unit = "GHz";
		} else {
			unit = "MHz";
		}
		fetcher.ento.setFieldValue("cpu_freq", f);
		System.out.println("cpu_freq=" + f);
		fetcher.ento.setFieldValue("cpu_freq_unit", unit);
		System.out.println("cpu_freq_unit=" + unit);
	}

}
