package com.jinnova.biang.siteextractor.vatgia.mobile;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jinnova.biang.siteextractor.base.CombinedExtractor;
import com.jinnova.biang.siteextractor.base.DetailBase;
import com.jinnova.biang.siteextractor.base.ExtractNameSupport;
import com.jinnova.biang.siteextractor.base.Extractor;
import com.jinnova.biang.siteextractor.base.MultiChoiceExtractor;
import com.jinnova.biang.siteextractor.base.MultivalueExtractor;
import com.jinnova.biang.siteextractor.base.NumberExtractor;
import com.jinnova.biang.siteextractor.base.SimpleExtractor;

public class VatGiaMobileTechDetails2 extends DetailBase {

	@Override
	public String getCatId() {
		return "elec_comp_phone";
	}

	@Override
	public int getMinFieldCount() {
		return 15;
	}

	@Override
	public void setup() {
		
		
		extractors.put("Hãng sản xuất", new SimpleExtractor(this, "manu", 1));
		ExtractNameSupport mce = new MultiChoiceExtractor(this, "network_", 2);
		mce.ignores.add("hsdpa");
		mce.nameMasks.put("wcdma_2100", "wcdma_2100");
		mce.nameMasks.put("cdma_2000", "cdma_2000");
		extractors.put("Mạng", mce);
		extractors.put("Kiểu dáng", new SimpleExtractor(this, "style", 3));
		extractors.put("Màn hình", new SimpleExtractor(this, "screen", 4));
		extractors.put("Kích thước màn hình", new NumberExtractor(this, new String[] {"screen_dia"}, 5, " *[i|I][n|N][c|C][h|H]"));
		extractors.put("Độ phân giải màn hình", new NumberExtractor(this, new String[] {"screen_width", "screen_height"}, 6));
		extractors.put("Số lượng Cores", new Extractor() {
			@Override
			public void extract(String s) {
				int cores;
				s = s.toLowerCase();
				if (s.contains("single core")) {
					cores = 1;
				} else if (s.contains("dual core")) {
					cores = 2;
				} else if (s.contains("quad core")) {
					cores = 4;
				} else {
					throw new RuntimeException(s);
				}
				ento.setFieldValue("cpu_cores", String.valueOf(cores));
			}
		});

		final String ghz = "[G|g|M|m][h|H][z|Z]";
		final Pattern cpuFreg = Pattern.compile("[\\d|\\.]+ *" + ghz);
		//final Pattern cpuFregMHz = Pattern.compile("[\\d|\\.]+ *MHz");
		final Pattern numberPattern = Pattern.compile(NumberExtractor.NUMBER_REGEX);
		extractors.put("Bộ vi xử lý", new Extractor() {
			@Override
			public void extract(String s) {
				if (s == null || s.trim().isEmpty() || s.trim().equals("-")) {
					return;
				}
				Matcher m = cpuFreg.matcher(s);
				if (!m.find()) {
					//throw new RuntimeException("cpu freq invalid: " + s);
					return;
				}
				String f = s.substring(m.start(), m.end());
				m = numberPattern.matcher(f);
				m.find();
				f = f.substring(m.start(), m.end());
				String unit;
				if (s.toUpperCase().contains("GHZ")) {
					unit = "GHz";
				} else {
					unit = "MHz";
				}
				ento.setFieldValue("cpu_freq", f);
				ento.setFieldValue("cpu_freq_unit", unit);
				ento.setFieldValue("cpu_name", s);
			}
		});
		extractors.put("Bộ xử lý đồ hoạ", new SimpleExtractor(this, "gpu_name", 9));
		NumberExtractor ne = new NumberExtractor(this, "mem_internal", 10);
		extractors.put("Bộ nhớ", ne);
		extractors.put("Bộ nhớ trong", ne);
		extractors.put("ROM", ne);
		extractors.put("RAM", new NumberExtractor(this, "mem_ram", 11));
		extractors.put("Hệ điều hành", new SimpleExtractor(this, "os_name", 12));
		extractors.put("Sổ địa chỉ", new SimpleExtractor(this, "address_book", 13));
		extractors.put("Nhật ký cuộc gọi", new SimpleExtractor(this, "call_diary", 14));
		mce = new MultiChoiceExtractor(this, "messaging_", 15);
		mce.nameMasks.put("instant_messaging", "im");
		extractors.put("Tin nhắn", mce);
		mce = new MultiChoiceExtractor(this, "ringtone_", 16);
		mce.nameMasks.put("đa_âm_sắc", "multitone");
		//mce.ignores.add("đơn_âm");
		mce.skipUnknowns = true;
		extractors.put("Kiểu chuông", mce);
		mce = new MultiChoiceExtractor(this, "", 17);
		mce.nameMasks.put("Có", "vibration");
		extractors.put("Rung", mce);

		ne = new NumberExtractor(this, new String[] {"sim_count"}, 18, " *[s|S][i|I][m|M]");
		ne.failOnMoreNumbers = false;
		extractors.put("Số sim", ne);
		
		mce = new MultiChoiceExtractor(this, "mem_ext_", 19);
		mce.ignores.add("không_hỗ_trợ");
		//mce.ignores.add("gprs");
		mce.nameMasks.put("memory_stick_micro", "ms_micro");
		mce.nameMasks.put("msmicro", "ms_micro");
		mce.nameMasks.put("sdio", "sd");
		extractors.put("Loại thẻ nhớ tích hợp", mce);
		mce = new MultiChoiceExtractor(this, "connect_", 20);
		mce.ignores.add("wlan");
		mce.ignores.add("kiểu_khác");
		mce.nameMasks.put("hsdpa", "hsdpa");
		mce.nameMasks.put("hồng_ngoại", "ir");
		//mce.skipUnknowns = true;
		extractors.put("Đồng bộ hóa dữ liệu", mce);
		extractors.put("Kiểu kết nối", new MultiChoiceExtractor(this, "connectport_", 21));
		extractors.put("Camera", new NumberExtractor(this, "camera_res", 22));
		mce = new MultiChoiceExtractor(this, "", 23);
		mce.nameMasks.put("3_5_mm_audio_output_jack", "audio_jack_35");
		mce.nameMasks.put("kết_nối_gps", "gps_integrated");
		mce.nameMasks.put("loa_ngoài", "loud_speaker");
		mce.nameMasks.put("loa_thoại", "loud_speaker");
		mce.nameMasks.put("đèn_flash", "camera_flash");
		mce.nameMasks.put("video_720p", "video_record_720p");
		mce.nameMasks.put("video_1080p", "video_record_1080p");
		mce.nameMasks.put("ghi_âm", "voice_recorder");
		mce.nameMasks.put("kết_nối_tv", "tv_out");
		mce.nameMasks.put("radio", "radio");
		mce.nameMasks.put("xem_tivi", "tv_receiver");
		mce.nameMasks.put("công_nghệ_4g", "tech_4g");
		mce.nameMasks.put("usb_otg", "usb_otg");
		//mce.skipUnknowns = true;
		mce.ignores.add("mp4");
		mce.ignores.add("quay_video");
		mce.ignores.add("công_nghệ_3g");
		mce.ignores.add("video_call");
		mce.ignores.add("từ_điển_t9");
		extractors.put("Tính năng", mce);

		//other features
		CombinedExtractor ce = new CombinedExtractor();
		mce = new MultiChoiceExtractor(this, "", 24);
		mce.nameMasks.put("proximity_sensor", "sensor_proxi");
		mce.nameMasks.put("accelerometer_sensor", "sensor_accel");
		mce.nameMasks.put("digital_compass", "sensor_compass");
		mce.nameMasks.put("gyro_sensor", "sensor_gyro");
		mce.nameMasks.put("qwerty_keyboard", "qwerty_keyboard");
		mce.skipUnknowns = true;
		mce.ignores.add("mobile_chat_mode_for_sms");
		mce.ignores.add("organizer");
		mce.ignores.add("dual_sim");
		mce.ignores.add("tiếng_anh,_tiếng_việt");
		ce.extractors.add(mce);
		mce = new MultivalueExtractor(this, "feature_others", 24);
		ce.extractors.add(mce);
		extractors.put("Tính năng khác", ce);
		
		extractors.put("Màu", new MultivalueExtractor(this, "colors", 25));
		ce = new CombinedExtractor();
		ne = new NumberExtractor(this, "battery_capa", 26);
		ne.failOnLessNumbers = false;
		ce.extractors.add(ne);
		SimpleExtractor se = new SimpleExtractor(this, "battery_type", 26);
		se.nameMasks.put("li-ion", "Li-Ion");
		ce.extractors.add(se);
		extractors.put("Pin", ce);
		
		extractors.put("Thời gian đàm thoại", new NumberExtractor(this, "battery_voice", 27));
		extractors.put("Thời gian chờ", new NumberExtractor(this, "battery_standby", 28));
		extractors.put("Trọng lượng", new NumberExtractor(this, "weight", 29));
		extractors.put("Kích thước", new NumberExtractor(this, new String[] {"size_height", "size_width", "size_thick"}, 30));
	}

}
