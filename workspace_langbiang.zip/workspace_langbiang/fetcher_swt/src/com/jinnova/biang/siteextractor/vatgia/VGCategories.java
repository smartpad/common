package com.jinnova.biang.siteextractor.vatgia;

import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.siteextractor.base.FlowSupport;

public class VGCategories extends FlowSupport {
	
	private boolean done = false;

	@Override
	public void setup() {
		spec = EntoManager.instance.getSpec("vg_cat");
	}

	@Override
	protected String nextUrl() {
		if (done) {
			return null;
		}
		done = true;
		return "http://vatgia.com/home/shop.php";
	}

	@Override
	protected void processOnePage() {
		/*browser.evaluate("fetchingColumn = $($('li.shop_list')[0])");
		processOneColumn();*/
		browser.evaluate("allCats = $($('ul.shop')[0]).find('li.shop_list ul li a')");
		//browser.evaluate("alert(allCats.length)");
		//browser.evaluate("alert(allCats.next())");
		//browser.evaluate("alert(allCats.next().attr('href'))");
		//browser.evaluate("alert(fetchingHref.find('li.shop_list').length)");
		//System.out.println(browser.evaluate("return $(fetchingHref[0]).attr('href')"));
		
		for (int i = 0; i < 155; i++) {
			String count = (String) browser.evaluate("return $($(allCats[" + i + "]).children()[0]).text()");
			count = replace(count, "(");
			count = replace(count, ")");
			count = replace(count, ".");
			String href = (String) browser.evaluate("return $(allCats[" + i + "]).attr('href')");
			System.out.println(href + ": " + count);
			Ento e = spec.createEnto(null);
			e.setFieldValue("vg_id", href);
			e.setFieldValue("count", count);
			try {
				spec.insert(e);
			} catch (EntoPersistentException e1) {
				e1.printStackTrace();
			}
		}
	}
	
	/*private void processOneColumn() {
		
		boolean hasMore = (Boolean) browser.evaluate("return fetchingColumn.prop('nodeName') == 'LI'");
		if (!hasMore) {
			return;
		}

		//browser.evaluate("alert(fetchingColumn.prop('nodeName'))");
		browser.evaluate("fetchingCat = $(fetchingColumn.find('li')[0])");
		processOneGroup();
		
		browser.evaluate("fetchingColumn = fetchingColumn.next()");
		processOneColumn();
	}
	
	private void processOneGroup() {
		boolean hasMore = (Boolean) browser.evaluate("return fetchingCat.prop('nodeName') == 'LI'");
		if (!hasMore) {
			return;
		}
		
		//browser.evaluate("alert(fetchingCat.text())");
		String s = (String) browser.evaluate("return fetchingCat.text()");
		System.out.println(s);
		
		browser.evaluate("fetchingCat = fetchingCat.next()");
		processOneGroup();
	}*/

	@Override
	protected void setItemFetchStat(String s) {
		
	}

}
