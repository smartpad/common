package com.jinnova.biang.siteextractor;

import java.sql.SQLException;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.siteextractor.base.ListBase;
import com.jinnova.biang.siteextractor.vatgia.VGCategories;
import com.jinnova.biang.siteextractor.vatgia.VGShop;
import com.jinnova.biang.siteextractor.vatgia.mobile.VatGiaDesktopDetails;
import com.jinnova.biang.siteextractor.vatgia.mobile.VatGiaDesktopList;
import com.jinnova.biang.siteextractor.vatgia.mobile.VatGiaLaptopDetails;
import com.jinnova.biang.siteextractor.vatgia.mobile.VatGiaLaptopList;
import com.jinnova.biang.siteextractor.vatgia.mobile.VatGiaMobileTechDetails;
import com.jinnova.biang.siteextractor.vatgia.mobile.VatGiaMobileTechDetails2;
import com.jinnova.biang.siteextractor.vatgia.mobile.VatGiaTabletProductList;
import com.jinnova.biang.siteextractor.vatgia.mobile.VatGiaTabletTechDetails;

@SuppressWarnings("unused")
public class View extends ViewPart {
	
	public static final String ID = "SiteExtractor.view";
	
	//private static final String script = "window.document.getElementById('type_product_up')";

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 */
	public void createPartControl(Composite parent) {
		
		try {
			EntoManager.initialize();
			EntoManager.instance.load();
			//new VatGiaMobileProductList().createPartControl(parent);
			//new VatGiaMobileTechDetails2().createPartControl(parent);

			//new VatGiaTabletProductList().createPartControl(parent);
			//new VatGiaTabletTechDetails().createPartControl(parent);

			//new VatGiaLaptopList().createPartControl(parent);
			//new VatGiaLaptopDetails().createPartControl(parent);
			
			//new ListBase("http://vatgia.com/1256,week/may-tinh-desktop.html,", "e_elec_comp_desktop", 353).createPartControl(parent);
			//new VatGiaDesktopDetails().createPartControl(parent);
			
			new VGShop().createPartControl(parent);
			//new VGCategories().createPartControl(parent);
			
		} catch (EntoPersistentException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
	}
}