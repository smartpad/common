package com.jinnova.biang.siteextractor.vatgia.mobile;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashSet;

import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.browser.ProgressListener;
import org.eclipse.swt.widgets.Composite;

import com.jinnova.biang.siteextractor.base.FetcherBase;

public class VatGiaDesktopList extends FetcherBase implements ProgressListener {
	
	//private static final String url = "http://vatgia.com/438,month/mobile.html,";
	private static final String url = "http://vatgia.com/1256,week/may-tinh-desktop.html,";

	private PreparedStatement stmt;
	
	private int pageCount = 1;

	private HashSet<String> fetchedUrls;

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 * @throws SQLException 
	 */
	public void createPartControl(Composite parent) {
		
		String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
		Connection conn;
		try {
			conn = DriverManager.getConnection (url, "root", "");
			stmt = conn.prepareStatement("insert into e_elec_comp_desktop (vg_url) values (?)");
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		
		browser = new Browser(parent, SWT.None);
		browser.addProgressListener(this);
		fetchedUrls = new HashSet<>();
		loadPage();
	}
	
	private void loadPage() {

		if (pageCount < 353) {
			String s = url + pageCount + "_30";
			System.out.println(pageCount + ": " + s);
			browser.setUrl(s);
			pageCount++;
		}
	}
	
	@Override
	public void completed(ProgressEvent arg0) {
		try {
			processOnePage();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		loadPage();
	}
	
	@Override
	public void changed(ProgressEvent arg0) {
		
	}
	
	private void processOnePage() throws SQLException {
		
		browser.evaluate("fetchContainer = window.document.getElementById('type_product')"); //div
		browser.evaluate("fetchContainer = fetchContainer.getElementsByTagName('a')"); //collection of items
		int itemIndex = -1;
		
		while (true) {
			itemIndex++;
			browser.evaluate("fetchItem = fetchContainer[" + itemIndex + "]");
			boolean noMore = (boolean) browser.evaluate("return fetchItem == null");
			if (noMore) {
				break;
			}
			
			String url = (String) browser.evaluate("return fetchItem.href");
			if (fetchedUrls.contains(url)) {
				continue;
			}
			fetchedUrls.add(url);
			System.out.println(url);
			
			//insert db
			//stmt.setString(1, name);
			stmt.setString(1, url);
			stmt.executeUpdate();
		}
	}
}
