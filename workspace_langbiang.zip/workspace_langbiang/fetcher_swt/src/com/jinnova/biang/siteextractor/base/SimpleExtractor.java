package com.jinnova.biang.siteextractor.base;

import java.util.HashMap;

public class SimpleExtractor implements ExtractorHref {
	
	final FetcherBase fetcher;

	final String fieldName;
	
	private final int fieldIndex;
	
	public final HashMap<String, String> nameMasks = new HashMap<>();
	
	public boolean href = false;
	
	public boolean innerHTML = false;
	
	/**
	 * 
	 */
	
	public SimpleExtractor(FetcherBase fetcher, String fieldName, int fieldIndex) {
		this.fetcher = fetcher;
		this.fieldName = fieldName;
		this.fieldIndex = fieldIndex;
	}

	@Override
	public boolean isHrefValue() {
		return href;
	}

	@Override
	public boolean isInnerHTML() {
		return innerHTML;
	}
	
	@Override
	public void extract(String s) {
		s = s.trim();
		s = s.replaceAll("\n", "");
		
		String replaced = ExtractNameSupport.replaceAllSpecials(s);
		for (String key : nameMasks.keySet()) {
			if (replaced.contains(key.toLowerCase())) {
				s = nameMasks.get(key);
				if (s == null) {
					//ignore requested
					return;
				}
				break;
			}
		}
		System.out.println("Field " + fieldIndex + ": " + fieldName + "=" + s);
		this.fetcher.ento.setFieldValue(fieldName, s);
		
		/*Object[] normal = normalize(s);
		if (normal == null) {
			throw new RuntimeException();
			//return;
		}
		
		String actualValue;
		if ((Boolean) normal[1]) {
			actualValue = (String) normal[0];
		} else {
			actualValue = s;
		}
		this.fetcher.ento.setFieldValue(fieldName, actualValue);*/
	}
}