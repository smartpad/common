package com.jinnova.biang.siteextractor.base;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.browser.ProgressListener;
import org.eclipse.swt.widgets.Composite;

import com.jinnova.biang.ento.EntoPersistentException;

public abstract class FlowSupport extends FetcherBase implements ProgressListener {
	
	private int itemCount = 1;
	private int itemCountSuccess = 0;
	
	private long loadTimeStart, loadTimeEnd, fetchTimeStart, fetchTimeEnd;
	
	private final Object eventCompleteLock = new Object();
	private boolean waitingEventComplete = false;

	private String debuggingUrl;
	
	public abstract void setup();
	
	protected abstract String nextUrl();
	
	protected abstract void processOnePage();
	
	protected abstract void setItemFetchStat(String s);

	/**
	 * This is a callback that will allow us to create the viewer and initialize it.
	 * @throws EntoPersistentException 
	 */
	public final void createPartControl(final Composite parent) throws EntoPersistentException {
		
		browser = new Browser(parent, SWT.None);
		browser.addProgressListener(this);
		//debuggingUrl = "one url";
		debugging = debuggingUrl != null;
		setup();
		loadPage();
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				while (true) {
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
					synchronized (eventCompleteLock) {
						if (waitingEventComplete && System.currentTimeMillis() - loadTimeStart > 30000) {
							waitingEventComplete = false;
							setItemFetchStat("error_loading_nonstop");
							System.out.println("*****error_loading_nonstop");
							parent.getDisplay().asyncExec(new Runnable() {
								
								@Override
								public void run() {
									loadPage();
								}
							});
						}
					}
				}
			}
		}).start();
	}
	
	private void loadPage() {
		
		String url = nextUrl();
		fetchTimeEnd = System.currentTimeMillis();
		System.out.println(new Date() + " - " + itemCount++ + " (" + itemCountSuccess + "): " + (loadTimeEnd - loadTimeStart) + 
				"|" + (fetchTimeEnd - fetchTimeStart) + ": " + url);
		
		if (url == null) {
			return;
		}
		loadTimeStart = System.currentTimeMillis();
		setItemFetchStat("processed");
		browser.setUrl(url);
		
		synchronized (eventCompleteLock) {
			waitingEventComplete = true;
		}
	}
	
	@Override
	public final void completed(ProgressEvent arg0) {
		synchronized (eventCompleteLock) {
			if (!waitingEventComplete) {
				return;
			}
			waitingEventComplete = false;
		}
		loadTimeEnd = System.currentTimeMillis();
		fetchTimeStart = System.currentTimeMillis();
		try {
			processOnePage();
		} catch (SWTException e) {
			setItemFetchStat("error_scrip_nav");
			System.out.println("*****SWTException at field " + ": " + e.getMessage());
		}
		if (debuggingUrl != null) {
			return;
		}
		loadPage();
	}
	
	@Override
	public final void changed(ProgressEvent arg0) {
		
	}
	
	protected String evaluate(String expression) {
		String s = (String) browser.evaluate("return " + expression);
		if (s == null) {
			System.out.println("No script value for " + expression);
			return null;
		}
		s = s.trim();
		return s;
	}
	
	protected String replace(String s, String removal) {
		if (s == null) {
			return null;
		}
		return s.replace(removal, "");
	}
	
	protected String trim(String s) {
		if (s == null) {
			return null;
		}
		return s.trim();
	}
	
	protected boolean startsWith(String s, String prefix) {
		if (s == null) {
			return false;
		}
		return s.startsWith(prefix);
	}
	
	protected String substring(String s, int beginIndex) {
		if (s == null) {
			return null;
		}
		return s.substring(beginIndex);
	}
	
	protected List<String> split(String s, String delims) {
		if (s == null) {
			return null;
		}
		String[] splits = s.split(delims);
		LinkedList<String> l = new LinkedList<>();
		for (int i = 0; i < splits.length; i++) {
			l.add(splits[i].trim());
		}
		return l;
	}

}
