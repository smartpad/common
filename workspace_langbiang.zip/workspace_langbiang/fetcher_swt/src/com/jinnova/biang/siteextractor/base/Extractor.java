package com.jinnova.biang.siteextractor.base;

public interface Extractor {
	void extract(String s);
}