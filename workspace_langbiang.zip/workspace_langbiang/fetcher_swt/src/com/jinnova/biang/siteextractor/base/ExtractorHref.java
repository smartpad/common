package com.jinnova.biang.siteextractor.base;

public interface ExtractorHref extends Extractor {
	
	boolean isHrefValue();
	
	boolean isInnerHTML();
}
