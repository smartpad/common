package com.jinnova.biang.ento;

public enum EntoSpecFieldType {

	Boolean,
	Int,
	Decimal,
	Text_ID,
	Text_Name,
	Text_Desc,
	SQL_Text,
	
	VARCHAR_1024,
	VARCHAR_512,
	VARCHAR_255;
}
