package com.jinnova.biang.ento;

import java.util.List;

public class EntoAssociation extends EntoExtension {
	
	public final String name;

	public EntoAssociation(String name, EntoSpec spec, List<KeyPair> keys) {
		super(spec, keys);
		this.name = name;
	}

}
