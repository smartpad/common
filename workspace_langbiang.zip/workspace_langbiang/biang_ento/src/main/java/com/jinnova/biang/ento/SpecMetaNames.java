package com.jinnova.biang.ento;

public enum SpecMetaNames {

}
