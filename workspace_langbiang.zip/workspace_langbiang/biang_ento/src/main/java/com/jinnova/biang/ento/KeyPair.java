package com.jinnova.biang.ento;

public class KeyPair {

	public final String key;
	
	public final String foreignKey;

	public KeyPair(String key, String foreignKey) {
		super();
		this.key = key;
		this.foreignKey = foreignKey;
	}
}
