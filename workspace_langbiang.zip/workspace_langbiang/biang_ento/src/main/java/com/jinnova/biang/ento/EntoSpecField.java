package com.jinnova.biang.ento;

public class EntoSpecField {
	
	public final String id;
	
	public final EntoSpecFieldType fieldType;
	
	public final boolean multivalue;
	
	private String persistState = null;

	EntoSpecField(String name, EntoSpecFieldType fieldType, boolean multivalue) {
		this.id = name;
		this.fieldType = fieldType;
		this.multivalue = multivalue;
	}
	
	void setPersistState(String s) {
		this.persistState = s;
	}
	
	public void clearPersistState() {
		this.persistState = null;
	}
	
	public boolean isPersistStateNew() {
		return "new".equals(persistState);
	}
}
