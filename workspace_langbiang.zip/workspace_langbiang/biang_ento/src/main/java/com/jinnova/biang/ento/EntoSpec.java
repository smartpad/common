package com.jinnova.biang.ento;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;

public class EntoSpec {
	
	public final String specId;
	
	//private final HashMap<EntoSpec, List<KeyPair>> superSpecs = new HashMap<>();
	private final LinkedList<EntoSpec> superSpecs = new LinkedList<>();
	
	private final LinkedHashMap<String, EntoSpecField> allFields = new LinkedHashMap<>();
	
	//private final HashSet<HashSet<EntoSpecField>> uniqueKeys = new HashSet<>();
	
	//private final LinkedList<EntoAssociation> associations = new LinkedList<>();
	
	//private final LinkedList<EntoExtension> references = new LinkedList<>();
	
	private final LinkedHashMap<Long, Ento> entoMap = new LinkedHashMap<>();
	
	private final HashMap<EntoSpecField, HashMap<String, Ento>> indexes = new HashMap<>();
	
	private JsonObject meta;
	
	/*static EntoSpec createRootSpec() {
		return new EntoSpec(null);
	}
	
	static EntoSpec createSpec(String specId) {
		if (specId == null) {
			throw new NullPointerException();
		}
		return new EntoSpec(specId);
		
	}*/
	
	EntoSpec(String specId) {
		this.specId = specId;
	}

	void load(String metaString) {
		
		if (metaString == null) {
			//addSuperSpec(EntoManager.instance.rootSpec, null);
			return;
		}
		JsonObject specJson;
		try {
			specJson = new JsonParser().parse(metaString).getAsJsonObject();
		} catch (JsonSyntaxException e) {
			System.out.println("JsonSyntaxException: " + metaString);
			throw e;
		}
		JsonElement specParents = specJson.get("specParents");
		if (specParents != null) {
			Iterator<JsonElement> specParentIt = specParents.getAsJsonArray().iterator();
			while (specParentIt.hasNext()) {
				String oneParent = specParentIt.next().getAsString();
				EntoSpec parentSpec = EntoManager.instance.getSpec(oneParent);
				addSuperSpec(parentSpec, null);
			}
		}
		
		Iterator<JsonElement> fieldsIt = specJson.get("fields").getAsJsonArray().iterator();
		while (fieldsIt.hasNext()) {
			JsonObject oneFieldJson = fieldsIt.next().getAsJsonObject();
			boolean multivalue;
			JsonElement e = oneFieldJson.get("multivalue");
			if (e != null && !e.isJsonNull()) {
				multivalue = e.getAsBoolean();
			} else {
				multivalue = false;
			}
			createFieldInternal(oneFieldJson.get("id").getAsString(), 
					EntoSpecFieldType.valueOf(oneFieldJson.get("type").getAsString()), multivalue);
		}
	}

	public List<EntoSpec> getSuperSpecsDirect() {
		synchronized (superSpecs) {
			return new LinkedList<>(superSpecs);
		}
	}

	public Iterator<EntoSpec> getSuperSpecsDirectIterator() {
		synchronized (superSpecs) {
			return new LinkedList<>(superSpecs).iterator();
		}
	}
	
	public List<EntoSpec> getSuperSpecsAll() {
		return null; //TODO
	}
	
	boolean isChildDirectly(EntoSpec spec) {
		return superSpecs.contains(spec);
	}
	
	public void addSuperSpec(EntoSpec oneSuper, List<KeyPair> keyPairs) {
		if (oneSuper == null) {
			throw new NullPointerException();
		}
		synchronized (superSpecs) {
			//superSpecs.add(new EntoExtension(oneSuper, keyPairs));
			superSpecs.add(oneSuper);
		}
		
		//if (oneSuper != EntoManager.instance.rootSpec) {
			if (meta == null) {
				meta = new JsonObject();
			}
			JsonArray parentSpecs = meta.getAsJsonArray("specParents");
			if (parentSpecs == null) {
				parentSpecs = new JsonArray();
				meta.add("specParents", parentSpecs);
			}
			parentSpecs.add(new JsonPrimitive(oneSuper.specId));
		//}
	}
	
	public void createField(String fieldId, EntoSpecFieldType fieldType) {
		EntoSpecField f = createFieldInternal(fieldId, fieldType, false);
		f.setPersistState("new");
	}
	
	public void createField(String fieldId, EntoSpecFieldType fieldType, boolean multivalue) {
		EntoSpecField f = createFieldInternal(fieldId, fieldType, multivalue);
		f.setPersistState("new");
	}
	
	private EntoSpecField createFieldInternal(String fieldId, EntoSpecFieldType fieldType, boolean multivalue) {
		EntoSpecField f = new EntoSpecField(fieldId, fieldType, multivalue);
		allFields.put(fieldId, f);
		if (meta == null) {
			meta = new JsonObject();
		}
		JsonArray fields = meta.getAsJsonArray("fields");
		if (fields == null) {
			fields = new JsonArray();
			meta.add("fields", fields);
		}
		
		JsonObject fieldJson = new JsonObject();
		fieldJson.addProperty("id", fieldId);
		fieldJson.addProperty("type", fieldType.name());
		fieldJson.addProperty("multivalue", multivalue);
		fields.add(fieldJson);
		return f;
	}
	
	/*public void clearFieldNewFlags() {
		if (meta == null) {
			return;
		}
		JsonArray fields = meta.getAsJsonArray("fields");
		if (fields == null) {
			return;
		}
		Iterator<JsonElement> it = fields.iterator();
		while (it.hasNext()) {
			JsonObject fieldJson = it.next().getAsJsonObject();
			fieldJson.remove("persistState");
		}
	}*/
	
	/*public EntoSpec createSubSpec(String subSpecId) {
		EntoSpec subSpec = new EntoSpec(subSpecId);
		//allSpecs.put(specId, spec);
		return subSpec;
	}*/
	
	public Ento getEnto(long entoId) {
		return entoMap.get(entoId);
	}
	
	public void createIndex(EntoSpecField field) {
		if (indexes.containsKey(field)) {
			return;
		}
		HashMap<String, Ento> oneIndex = new HashMap<>();
		for (Ento e : entoMap.values()) {
			oneIndex.put(e.getFieldValue(field.id), e);
			
		}
		indexes.put(field, oneIndex);
		System.out.println("Indexed " + oneIndex.size() + " entos of " + this.specId + " on " +
				field + " (" + field.id + ")");
	}
	
	public Ento getEnto(EntoSpecField field, String value) {
		HashMap<String, Ento> oneIndex = indexes.get(field);
		if (oneIndex == null) {
			throw new RuntimeException("Unindexed field: " + field + " (" + field.id + ")");
		}
		return oneIndex.get(value);
	}
	
	public EntoSpecField getField(String fieldId) {
		return allFields.get(fieldId);
	}
	
	public LinkedList<EntoSpecField> getAllFields() {
		return new LinkedList<>(allFields.values());
	}
	
	public Ento createEnto(List<Ento> supers) {
		return new Ento(this, supers);
	}
	
	public void load(long id, Ento ento, HashMap<String, Long> superIds, String entoMeta, Object jsonParser) {
		JsonObject entoMetaJson;
		if (entoMeta != null) {
			entoMetaJson = ((JsonParser) jsonParser).parse(entoMeta).getAsJsonObject();
		} else {
			entoMetaJson = null;
		}
		ento.load(id, superIds, entoMetaJson);
		entoMap.put(id, ento);
	}
	
	public void insert(Ento ento) throws EntoPersistentException {
		if (ento.isStored()) {
			throw new RuntimeException();
		}
		long newRevision = EntoManager.instance.persistor.insert(ento);
		load(newRevision, ento, null, null, null);
		
		Iterator<Entry<EntoSpecField, HashMap<String, Ento>>> it = indexes.entrySet().iterator();
		while (it.hasNext()) {
			Entry<EntoSpecField, HashMap<String, Ento>> entry = it.next();
			entry.getValue().put(ento.getFieldValue(entry.getKey().id), ento);
		}
	}
	
	public void update(Ento ento) throws EntoPersistentException {
		if (!ento.isStored()) {
			throw new RuntimeException();
		}
		EntoManager.instance.persistor.update(ento);
	}
	
	public Object update(Ento ento, Object preparedStatement) throws EntoPersistentException {
		if (!ento.isStored()) {
			throw new RuntimeException();
		}
		return EntoManager.instance.persistor.update(ento, preparedStatement);
	}

	public String getMetaString() {
		return new Gson().toJson(meta);
	}
	
	public List<Ento> getAllEntos() {
		return new LinkedList<>(entoMap.values());
	}

	public void buildLinks() {
		for (Ento e : entoMap.values()) {
			e.buildLinks();
		}
		
	}
}
