package com.jinnova.biang.ento;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

/**
 * @author Huy Banh
 * 
 * All entos are rooted at Ento
 * 
 * For each ento, there are two tables:
 *    + e_<ento_name>: ento data
 *    + a_<ento_name>: app data for each ento data record
 *    
 * e_ento table is a preinstalled table, the root of all other entos
 * 
 * e_ento table has only two columns: revision and ento_id
 *
 */
public class Ento {
	
	private static final long ENTO_ID_UNINITIALIZED = 0;
	
	private long id = ENTO_ID_UNINITIALIZED;
	
	//private long revision;
	
	public final EntoSpec spec;
	
	private JsonObject meta;
	
	private String updateBy;

	private LinkedHashMap<EntoSpec, Ento> superEntos;
	
	private final LinkedList<Ento> subEntos = new LinkedList<>();
	
	private final LinkedList<Ento> referTo = new LinkedList<>();
	
	private final LinkedList<Ento> referedFrom = new LinkedList<>();
	
	private final LinkedHashMap<String, JsonElement> fieldValueMap = new LinkedHashMap<>();

	private HashMap<String, Long> superIdsForLoading;
	
	Ento(EntoSpec spec, List<Ento> supers) {
		this.spec = spec;
		if (supers != null) {
			this.superEntos = new LinkedHashMap<>();
			for (Ento e : supers) {
				if (!spec.isChildDirectly(e.spec)) {
					throw new RuntimeException(spec.specId + " is not a direct-child of " + e.spec.specId);
				}
				addSuper(e);
			}
		}
	}
	
	private void addSuper(Ento oneSuper) {
		if (this.superEntos == null) {
			this.superEntos = new LinkedHashMap<>();
		}
		this.superEntos.put(oneSuper.spec, oneSuper);
		oneSuper.subEntos.add(this);
	}
	
	public void addReferTo(Ento referedEnto) {
		
		linkReferTo(referedEnto);
		if (this.meta == null) {
			this.meta = new JsonObject();
		}
		JsonElement referJson = this.meta.get("referTo");
		if (referJson == null) {
			referJson = new JsonArray();
			this.meta.add("referTo", referJson);
		}
		
		JsonArray oneRefer = new JsonArray();
		oneRefer.add(new JsonPrimitive(referedEnto.spec.specId));
		oneRefer.add(new JsonPrimitive(referedEnto.getId()));
		referJson.getAsJsonArray().add(oneRefer);
	}
	
	/*void setId(long id) {
		this.id = id;
	}*/
	
	public long getId() {
		return this.id;
	}
	
	public JsonObject getMeta() {
		return meta;
	}
	
	boolean isStored() {
		return this.id != ENTO_ID_UNINITIALIZED;
	}
	
	/*void setRevision(long r) {
		this.revision = r;
	}*/
	
	public Ento getSuperEnto(EntoSpec superSpec) {
		if (this.superEntos == null) {
			return null;
		}
		return this.superEntos.get(superSpec);
	}
	
	public List<Ento> getSubEntos(boolean direct) {
		return new LinkedList<>(this.subEntos);
	}

	/*public List<Ento> getAssociatedEntos(boolean direct) {
		return null;
	}*/
	
	public List<Ento> getReferTo(boolean direct) {
		return new LinkedList<>(this.referTo);
	}
	
	public List<Ento> getReferedFrom(boolean direct) {
		return new LinkedList<>(this.referedFrom);
	}
	
	public void setFieldValue(String fieldId, String value) {
		EntoSpecField field = spec.getField(fieldId);
		if (field == null) {
			throw new IllegalArgumentException(fieldId);
		}
		if (value == null) {
			fieldValueMap.put(fieldId, null);
		} else {
			fieldValueMap.put(fieldId, new JsonPrimitive(value));
		}
	}
	
	public void loadFieldValueSerialized(String fieldId, String valueSerialized, Object parser) {
		
		EntoSpecField field = spec.getField(fieldId);
		if (field == null) {
			throw new IllegalArgumentException(fieldId);
		}

		if (valueSerialized == null) {
			return;
		}
		
		if (field.multivalue) {
			JsonElement e = ((JsonParser) parser).parse(valueSerialized);
			fieldValueMap.put(fieldId, e);
		} else {
			fieldValueMap.put(fieldId, new JsonPrimitive(valueSerialized));
		}
	}
	
	public void setFieldValue(String fieldId, List<String> values) {
		EntoSpecField field = spec.getField(fieldId);
		if (field == null) {
			throw new IllegalArgumentException(fieldId);
		}
		JsonArray ja = new JsonArray();
		for (String one : values) {
			ja.add(new JsonPrimitive(one));
		}
		fieldValueMap.put(fieldId, ja);
	}
	
	public String getFieldValueSerialized(String fieldId) {
		
		EntoSpecField field = spec.getField(fieldId);
		if (field.multivalue) {
			JsonElement e = fieldValueMap.get(fieldId);
			if (e == null || e.isJsonNull()) {
				return null;
			}
			return new Gson().toJson(e);
			//return e.toString();
		} else {
			JsonElement e = fieldValueMap.get(fieldId);
			if (e == null || e.isJsonNull()) {
				return null;
			}
			return e.getAsString();
		}
	}
	
	public String getFieldValue(String fieldId) {
		JsonElement e = fieldValueMap.get(fieldId);
		if (e == null) {
			return null;
		}
		if (e.isJsonPrimitive()) {
			return e.getAsString();
		}
		return null;
	}
	
	public List<String> getFieldValues(String fieldId) {
		JsonElement e = fieldValueMap.get(fieldId);
		if (e == null) {
			return null;
		}
		if (e.isJsonArray()) {
			LinkedList<String> values = new LinkedList<>();
			Iterator<JsonElement> it = e.getAsJsonArray().iterator();
			while (it.hasNext()) {
				String one = it.next().getAsString();
				values.add(one);
			}
			return values;
		}
		return null;
	}
	
	public LinkedHashMap<String, JsonElement> getAllFields() {
		return new LinkedHashMap<>(fieldValueMap);
	}

	/*void setSuperIdsForLoading(HashMap<String, Long> superIds) {
		this.superIdsForLoading = superIds;
	}*/

	void buildLinks() {
		linkSupers();
		linkRefers();
	}
	
	private void linkSupers() {
		if (this.superIdsForLoading == null) {
			return;
		}
		this.superEntos = new LinkedHashMap<>();
		for (Entry<String, Long> superIdEntry : this.superIdsForLoading.entrySet()) {
			Long superId = superIdEntry.getValue();
			if (superId == null) {
				System.out.println("Data error: null super id");
				continue;
			}
			Ento superEnto = EntoManager.instance.getEnto(superIdEntry.getKey(), superId);
			if (superEnto == null) {
				System.out.println("Data error: super ento not found: " + superIdEntry.getKey() + "/" + superIdEntry.getValue());
				continue;
			}
			addSuper(superEnto);
			//System.out.println("Linked super ento");
		}
	}
	
	private void linkRefers() {
		if (this.meta == null) {
			return;
		}
		JsonElement referJson = this.meta.get("referTo");
		if (referJson == null) {
			return;
		}
		
		Iterator<JsonElement> it = referJson.getAsJsonArray().iterator();
		while (it.hasNext()) {
			JsonArray oneReferJson = it.next().getAsJsonArray();
			Ento referedEnto = EntoManager.instance.getEnto(oneReferJson.get(0).getAsString(), oneReferJson.get(1).getAsLong());
			if (referedEnto == null) {
				System.out.println("Data error: refered ento not found: " + 
						oneReferJson.get(0).getAsString() + "/" + oneReferJson.get(1).getAsLong());
				continue;
			}
			linkReferTo(referedEnto);
			
		}
	}
	
	private void linkReferTo(Ento referedEnto) {
		this.referTo.add(referedEnto);
		referedEnto.referedFrom.add(this);
	}

	void load(long entoId, HashMap<String, Long> superIds, JsonObject entoMeta) {
		this.id = entoId;
		//this.revision = id;
		this.superIdsForLoading = superIds;
		this.meta = entoMeta;
	}
	
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
}
