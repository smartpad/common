/**
 * 
 */
package com.jinnova.biang.ento;

/**
 * @author huyba
 *
 */
public class EntoPersistentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1114429847011496948L;

	/**
	 * 
	 */
	public EntoPersistentException() {
	}

	/**
	 * @param arg0
	 */
	public EntoPersistentException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public EntoPersistentException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public EntoPersistentException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 */
	public EntoPersistentException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
