package com.jinnova.biang.ento;

import java.sql.PreparedStatement;
import java.util.HashMap;

public interface EntoPersistentProvider {

	void createDatastore() throws EntoPersistentException;

	void insert(EntoSpec spec) throws EntoPersistentException;

	void update(EntoSpec spec) throws EntoPersistentException;

	long insert(Ento ento) throws EntoPersistentException;

	void update(Ento ento) throws EntoPersistentException;

	PreparedStatement update(Ento ento, Object preparedStatement) throws EntoPersistentException;
	
	HashMap<String, String> loadHierachy() throws EntoPersistentException;

	void loadEntos(EntoSpec oneSpec, Object jsonParser) throws EntoPersistentException;
}
