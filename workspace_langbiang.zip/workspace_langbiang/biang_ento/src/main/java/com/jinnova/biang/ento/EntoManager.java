package com.jinnova.biang.ento;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import com.google.gson.JsonParser;

public class EntoManager {
	
	public static EntoManager instance;
	
	//public final EntoSpec rootSpec;
	
	final EntoPersistentProvider persistor;
	
	private final HashMap<String, EntoSpec> allSpecs = new HashMap<>();
	
	public static void initialize() throws EntoPersistentException {
		if (instance != null) {
			return;
		}
		instance = new EntoManager();
	}
	
	private EntoManager() {
		
		try {
			persistor = (EntoPersistentProvider) Class.forName("com.jinnova.biang.ento.db.MysqlPersistor").newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			
			throw new RuntimeException(e);
		}
		
		/*rootSpec = new EntoSpec(null);
		rootSpec.createField("revision", EntoSpecFieldType.Int);
		rootSpec.createField("ento_id", EntoSpecFieldType.Int);
		allSpecs.put(null, rootSpec);*/
	}
	
	public void load() throws EntoPersistentException {
		
		//load specs
		HashMap<String, String> hierachyMap = persistor.loadHierachy();
		//HashMap<String, EntoSpec> allSpecs = new HashMap<>();
		Iterator<Entry<String, String>> hierachyIt = hierachyMap.entrySet().iterator();
		while (hierachyIt.hasNext()) {
			Entry<String, String> mapEntry = hierachyIt.next();
			String specId = mapEntry.getKey();
			//allSpecs.put(specId, EntoSpec.createSpec(specId));
			createSpec(specId);
		}
		
		//link inheritances / build spec structures
		hierachyIt = hierachyMap.entrySet().iterator();
		while (hierachyIt.hasNext()) {
			Entry<String, String> mapEntry = hierachyIt.next();
			EntoSpec oneSpec = allSpecs.get(mapEntry.getKey());
			oneSpec.load(mapEntry.getValue());
		}
		
		//load spec entries
		JsonParser jsonParser = new JsonParser();
		hierachyIt = hierachyMap.entrySet().iterator();
		while (hierachyIt.hasNext()) {
			Entry<String, String> mapEntry = hierachyIt.next();
			EntoSpec oneSpec = allSpecs.get(mapEntry.getKey());
			persistor.loadEntos(oneSpec, jsonParser);
		}
		
		//link entry-supers
		hierachyIt = hierachyMap.entrySet().iterator();
		while (hierachyIt.hasNext()) {
			Entry<String, String> mapEntry = hierachyIt.next();
			EntoSpec oneSpec = allSpecs.get(mapEntry.getKey());
			oneSpec.buildLinks();
		}
	}
	
	/*public Ento getEnto(long specId, long entoId) {
		EntoSpec spec = allSpecs.get(specId);
		//return spec.getEnto(entoId);
		return spec.getEnto(entoId);
	}*/
	
	/*public void loadSpec(String specId, String specJson) {
		
	}*/
	
	public void createDatastore() throws EntoPersistentException {
		persistor.createDatastore();
	}
	
	public EntoSpec getSpec(String specId) {
		return allSpecs.get(specId);
	}
	
	public Ento getEnto(String specId, long entoId) {
		EntoSpec superSpec = allSpecs.get(specId);
		if (superSpec == null) {
			return null;
		}
		return superSpec.getEnto(entoId);
	}
	
	public EntoSpec createSpec(String specId) {
		if (specId == null) {
			throw new NullPointerException();
		}
		return createSpecInternal(specId);
	}
	
	private EntoSpec createSpecInternal(String specId) {
		EntoSpec spec = new EntoSpec(specId);
		allSpecs.put(specId, spec);
		return spec;
	}
	
	public void insert(EntoSpec spec) throws EntoPersistentException {
		persistor.insert(spec);
	}
	
	public void update(EntoSpec spec) throws EntoPersistentException {
		persistor.update(spec);
	}
	
	public void dump(String prefix) {
		
		
	}

}
