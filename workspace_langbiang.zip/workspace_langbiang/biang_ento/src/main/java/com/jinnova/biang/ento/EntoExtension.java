package com.jinnova.biang.ento;

import java.util.List;

public class EntoExtension {
	
	//private final LinkedList<KeyPair> keys;

	public final EntoSpec parentSpec;
	
	public EntoExtension(EntoSpec parentSpec, List<KeyPair> keys) {
		super();
		this.parentSpec = parentSpec;
		/*if (keys == null) {
			this.keys = null;
		} else {
			this.keys = new LinkedList<>(keys);
		}*/
	}

}
