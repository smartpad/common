package com.jinnova.biang.ento.test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.ento.EntoSpec;
import com.jinnova.biang.ento.EntoSpecFieldType;
import com.jinnova.biang.ento.KeyPair;

public class CreatePrelimitaryData {

	/**
	 * @param args
	 * @throws EntoPersistentException 
	 */
	@SuppressWarnings("unused")
	public static void main(String[] args) throws EntoPersistentException {
		EntoManager.initialize();
		EntoSpec masterSpec = createCatSpec(null, "master_cat", null);
		Object[] masterType = new Object[] {null, masterSpec};
		
		//int[] masterOrd = new int[] {1};
		Object[] elec = createCatItem(masterType, "elec", "Điện tử & Máy tính");
		{
			int[] elecOrd = new int[] {1};
			Object[] elecComp = createCatItem(elec, "elec_comp", "Vi tính & viễn thông");
			{
				int[] elecCompOrd = new int[] {1};
				createCatItem(elecComp, "elec_comp_phone", "Điện thoại di động",
						new Object[][] {
							{"vg_url", EntoSpecFieldType.VARCHAR_255},
							{"fetch_stat", EntoSpecFieldType.Text_ID}});
				createCatItem(elecComp, "elec_comp_tablet", "Máy tính bảng");
				createCatItem(elecComp, "elec_comp_laptop", "Máy tính xách tay");
				createCatItem(elecComp, "elec_comp_desktop", "Máy tính để bàn");
				createCatItem(elecComp, "elec_comp_item", "Thiết bị ngoại vi");
			}
			Object[] elecCam = createCatItem(elec, "elec_cam", "Máy ảnh & Máy quay phim");
			Object[] elecAv = createCatItem(elec, "elec_av", "Âm thanh & Hình ảnh");
		}
		Object[] applicance = createCatItem(masterType, "appliance", "Điện gia dụng");
		createCatItem(masterType, "office", "Máy văn phòng & Văn phòng phẩm");
		
		createCatItem(masterType, "fmcg", "Hàng tiêu dùng");
		createCatItem(masterType, "clothes", "Quần áo, giầy dép & Trang sức");
		createCatItem(masterType, "kids", "Trẻ em & Đồ chơi");
		createCatItem(masterType, "health", "Y tế, sức khỏe & Làm đẹp");
		createCatItem(masterType, "home", "Gia đình & Nội ngoại thất");

		createCatItem(masterType, "entertain", "Du lịch, giải trí & ẩm thực");
		createCatItem(masterType, "sport", "Thể thao, văn hóa & Nghệ thuật");
		//createmasterType(masterType, "Sách & Thiết bị trường học");
		createCatItem(masterType, "edu", "Giáo dục, đào tạo & Việc làm");
		
		createCatItem(masterType, "transport", "Ô tô & Phương tiện vận tải");
		createCatItem(masterType, "realestate", "Địa ốc & Bất động sản");
		createCatItem(masterType, "industrials", "Công nghiệp, xây dựng & Doanh nghiệp");
		//createmasterType(masterType, "Việc làm");
	}
	
	private static final HashMap<EntoSpec, Integer> orderMap = new HashMap<>();
	
	private static Object[] createCatItem(Object[] parentEntoAndItemSpec, String catId, String name) throws EntoPersistentException {
		return createCatItem(parentEntoAndItemSpec, catId, name, null);
	}
	
	private static Object[] createCatItem(Object[] parentEntoAndItemSpec, String catId, String name, Object[][] cols) 
			throws EntoPersistentException {
		
		List<Ento> superEntos;
		if (parentEntoAndItemSpec[0] != null) {
			superEntos = Arrays.asList(new Ento[] {(Ento) parentEntoAndItemSpec[0]});
		} else {
			superEntos = null;
		}
		Ento e = ((EntoSpec) parentEntoAndItemSpec[1]).createEnto(superEntos);
		e.setFieldValue("name", name);
		Integer ord = orderMap.get((EntoSpec) parentEntoAndItemSpec[1]);
		if (ord == null) {
			ord = 1;
		}
		e.setFieldValue("ord", ord.toString());
		orderMap.put((EntoSpec) parentEntoAndItemSpec[1], ord + 1);
		//ord[0] = ord[0] + 1;
		((EntoSpec) parentEntoAndItemSpec[1]).insert(e);
		EntoSpec newSpec = createCatSpec((EntoSpec) parentEntoAndItemSpec[1], catId, cols);
		return new Object[] {e, newSpec};
	}
	
	private static EntoSpec createCatSpec(EntoSpec parentSpec, String catId, Object[][] cols) throws EntoPersistentException {
		EntoSpec cat = EntoManager.instance.createSpec(catId);
		if (parentSpec != null) {
			cat.addSuperSpec(parentSpec, Arrays.asList(new KeyPair("", "")));
		}
		//EntoSpec cat = parentSpec.createSubSpec(catId);
		cat.createField("name", EntoSpecFieldType.Text_Name);
		cat.createField("ord", EntoSpecFieldType.Int);
		if (cols != null) {
			for (int i = 0; i < cols.length; i++) {
				cat.createField((String) cols[i][0], (EntoSpecFieldType) cols[i][1]);
			}
		}
		EntoManager.instance.insert(cat);
		
		return cat;
	}

}
