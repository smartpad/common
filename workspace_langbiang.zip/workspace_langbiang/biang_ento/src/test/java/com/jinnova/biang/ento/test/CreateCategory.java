package com.jinnova.biang.ento.test;

import java.util.Arrays;
import java.util.List;

import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.ento.EntoSpec;
import com.jinnova.biang.ento.EntoSpecFieldType;
import com.jinnova.biang.ento.KeyPair;

public class CreateCategory {

	/**
	 * @param args
	 * @throws EntoPersistentException 
	 */
	public static void main(String[] args) throws EntoPersistentException {
		EntoManager.initialize();
		EntoManager.instance.load();
		//EntoSpec parentCat = EntoManager.instance.getSpec("elec_comp");
		//createCatSpec(parentCat, "biz",  
		createCatSpec(null, "vg_cat",
				new Object[][] {{"vg_id", EntoSpecFieldType.VARCHAR_255}});
		/*createCatItem(new Object[] {null, parentCat}, "elec_comp_desktop", "Máy tính để bàn", 
				new Object[][] {{"vg_url", EntoSpecFieldType.VARCHAR_1024},
				{"fetch_stat", EntoSpecFieldType.Boolean}}, 4);*/
	}
	
	@SuppressWarnings("unused")
	private static Object[] createCatItem(Object[] parentEntoAndItemSpec, String catId, String name, Object[][] cols, int ord) 
			throws EntoPersistentException {
		
		List<Ento> superEntos;
		if (parentEntoAndItemSpec[0] != null) {
			superEntos = Arrays.asList(new Ento[] {(Ento) parentEntoAndItemSpec[0]});
		} else {
			superEntos = null;
		}
		Ento e = ((EntoSpec) parentEntoAndItemSpec[1]).createEnto(superEntos);
		e.setFieldValue("name", name);
		e.setFieldValue("ord", String.valueOf(ord));
		((EntoSpec) parentEntoAndItemSpec[1]).insert(e);
		EntoSpec newSpec = createCatSpec((EntoSpec) parentEntoAndItemSpec[1], catId, cols);
		return new Object[] {e, newSpec};
	}
	
	private static EntoSpec createCatSpec(EntoSpec parentSpec, String catId, Object[][] cols) throws EntoPersistentException {
		EntoSpec cat = EntoManager.instance.createSpec(catId);
		if (parentSpec != null) {
			cat.addSuperSpec(parentSpec, Arrays.asList(new KeyPair("", "")));
		}
		//EntoSpec cat = parentSpec.createSubSpec(catId);
		cat.createField("name", EntoSpecFieldType.Text_Name);
		cat.createField("ord", EntoSpecFieldType.Int);
		if (cols != null) {
			for (int i = 0; i < cols.length; i++) {
				cat.createField((String) cols[i][0], (EntoSpecFieldType) cols[i][1]);
			}
		}
		EntoManager.instance.insert(cat);
		
		return cat;
	}

}
