package com.jinnova.biang.ento.test;

import java.util.List;

import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.ento.EntoSpec;

public class Startup {

	/**
	 * @param args
	 * @throws EntoPersistentException 
	 */
	public static void main(String[] args) throws EntoPersistentException {
		EntoManager.initialize();
		EntoManager.instance.load();
		
		EntoSpec masterCat = EntoManager.instance.getSpec("master_cat");
		List<Ento> masterCatItems = masterCat.getAllEntos();
		for (Ento e : masterCatItems) {
			dump(e, "");
		}
	}

	private static void dump(Ento e, String prefix) {
		System.out.println(prefix + e.getFieldValue("name"));
	}
}
