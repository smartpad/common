package com.jinnova.biang.ento.test;

import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.ento.EntoSpec;
import com.jinnova.biang.ento.EntoSpecFieldType;

public class MoreColumns extends MobileColumns {

	/**
	 * @param args
	 * @throws EntoPersistentException 
	 */
	public static void main(String[] args) throws EntoPersistentException {
		EntoManager.initialize();
		EntoManager.instance.load();
		EntoSpec spec = EntoManager.instance.getSpec("vg_cat");
		spec.createField("page", EntoSpecFieldType.Int);
		EntoManager.instance.update(spec);
	}
	
}
