package com.jinnova.biang.ento.test;

import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.ento.EntoSpec;
import com.jinnova.biang.ento.EntoSpecFieldType;

public class MobileColumns {

	/**
	 * @param args
	 * @throws EntoPersistentException 
	 */
	public static void main(String[] args) throws EntoPersistentException {
		EntoManager.initialize();
		EntoManager.instance.load();
		EntoSpec spec = EntoManager.instance.getSpec("elec_comp_phone");
		spec.createField("manu", EntoSpecFieldType.Text_Name);
		spec.createField("brand", EntoSpecFieldType.Text_Name);
		
		spec.createField("network_gsm_900", EntoSpecFieldType.Boolean);
		spec.createField("network_gsm_850", EntoSpecFieldType.Boolean);
		spec.createField("network_gsm_1800", EntoSpecFieldType.Boolean);
		spec.createField("network_gsm_1900", EntoSpecFieldType.Boolean);
		spec.createField("network_hsdpa_2100", EntoSpecFieldType.Boolean);
		spec.createField("network_hsdpa_900", EntoSpecFieldType.Boolean);
		spec.createField("network_hsdpa_850", EntoSpecFieldType.Boolean);
		spec.createField("network_hsdpa_1700", EntoSpecFieldType.Boolean);
		spec.createField("network_hsdpa_1900", EntoSpecFieldType.Boolean);
		spec.createField("network_cdma", EntoSpecFieldType.Boolean);
		spec.createField("network_cdma_800", EntoSpecFieldType.Boolean);
		spec.createField("network_cdma_1900", EntoSpecFieldType.Boolean);
		spec.createField("network_cdma_2000", EntoSpecFieldType.Boolean);
		spec.createField("network_wcdma_2100", EntoSpecFieldType.Boolean);
		spec.createField("network_umts_2100", EntoSpecFieldType.Boolean);
		spec.createField("network_umts_900", EntoSpecFieldType.Boolean);
		spec.createField("network_umts_850", EntoSpecFieldType.Boolean);
		
		spec.createField("style", EntoSpecFieldType.VARCHAR_255);
		spec.createField("screen", EntoSpecFieldType.VARCHAR_255);
		//spec.createField("screen_colors", EntoSpecFieldType.Decimal);
		spec.createField("screen_dia", EntoSpecFieldType.Decimal);
		spec.createField("screen_height", EntoSpecFieldType.Decimal);
		spec.createField("screen_width", EntoSpecFieldType.Decimal);
		spec.createField("cpu_cores", EntoSpecFieldType.Int);
		spec.createField("cpu_name", EntoSpecFieldType.VARCHAR_255);
		spec.createField("cpu_freq", EntoSpecFieldType.Decimal);
		spec.createField("cpu_freq_unit", EntoSpecFieldType.Text_ID);
		spec.createField("gpu_name", EntoSpecFieldType.VARCHAR_255);
		
		spec.createField("mem_ram", EntoSpecFieldType.VARCHAR_255);
		spec.createField("mem_internal", EntoSpecFieldType.VARCHAR_255);

		spec.createField("os_name", EntoSpecFieldType.VARCHAR_255);
		spec.createField("os_version", EntoSpecFieldType.VARCHAR_255);
		
		spec.createField("address_book", EntoSpecFieldType.VARCHAR_1024);
		spec.createField("call_diary", EntoSpecFieldType.VARCHAR_1024);
		spec.createField("messaging_email", EntoSpecFieldType.Boolean);
		spec.createField("messaging_mms", EntoSpecFieldType.Boolean);
		spec.createField("messaging_ems", EntoSpecFieldType.Boolean);
		spec.createField("messaging_sms", EntoSpecFieldType.Boolean);
		spec.createField("messaging_push_e_mail", EntoSpecFieldType.Boolean);
		spec.createField("messaging_im", EntoSpecFieldType.Boolean);
		spec.createField("messaging_imessage", EntoSpecFieldType.Boolean);
		
		spec.createField("ringtone_multitone", EntoSpecFieldType.Boolean);
		spec.createField("ringtone_mp3", EntoSpecFieldType.Boolean);
		spec.createField("ringtone_wav", EntoSpecFieldType.Boolean);
		
		spec.createField("vibration", EntoSpecFieldType.Boolean);
		spec.createField("sim_count", EntoSpecFieldType.Int);
		
		spec.createField("mem_ext_transflash", EntoSpecFieldType.Boolean);
		spec.createField("mem_ext_microsd", EntoSpecFieldType.Boolean);
		spec.createField("mem_ext_microsdhc", EntoSpecFieldType.Boolean);
		spec.createField("mem_ext_edge", EntoSpecFieldType.Boolean);
		spec.createField("mem_ext_rs_mmc", EntoSpecFieldType.Boolean);
		spec.createField("mem_ext_ms_micro", EntoSpecFieldType.Boolean);
		spec.createField("mem_ext_sd", EntoSpecFieldType.Boolean);
		
		spec.createField("connect_edge", EntoSpecFieldType.Boolean);
		spec.createField("connect_gprs", EntoSpecFieldType.Boolean);
		spec.createField("connect_wifi_802_11b", EntoSpecFieldType.Boolean);
		spec.createField("connect_wifi_802_11g", EntoSpecFieldType.Boolean);
		spec.createField("connect_wifi_802_11n", EntoSpecFieldType.Boolean);
		spec.createField("connect_bluetooth", EntoSpecFieldType.Boolean);
		spec.createField("connect_bluetooth_1_2", EntoSpecFieldType.Boolean);
		spec.createField("connect_bluetooth_2_0", EntoSpecFieldType.Boolean);
		spec.createField("connect_bluetooth_2_0_with_a2dp", EntoSpecFieldType.Boolean);
		spec.createField("connect_bluetooth_2_1_with_a2dp", EntoSpecFieldType.Boolean);
		spec.createField("connect_bluetooth_3_0_with_a2dp", EntoSpecFieldType.Boolean);
		spec.createField("connect_bluetooth_4_0_with_le_edr", EntoSpecFieldType.Boolean);
		spec.createField("connect_bluetooth_4_0", EntoSpecFieldType.Boolean);
		spec.createField("connect_hsdpa", EntoSpecFieldType.Boolean);
		spec.createField("connect_hscsd", EntoSpecFieldType.Boolean);
		spec.createField("connect_ir", EntoSpecFieldType.Boolean);
		
		spec.createField("connectport_microusb", EntoSpecFieldType.Boolean);
		spec.createField("connectport_usb", EntoSpecFieldType.Boolean);
		spec.createField("connectport_mini_usb", EntoSpecFieldType.Boolean);
		spec.createField("connectport_micro_hdmi", EntoSpecFieldType.Boolean);
		
		spec.createField("camera_res", EntoSpecFieldType.Decimal);
		//spec.createField("video_record_res", EntoSpecFieldType.VARCHAR_255);
		spec.createField("video_record_720p", EntoSpecFieldType.VARCHAR_255);
		spec.createField("video_record_1080p", EntoSpecFieldType.VARCHAR_255);
		spec.createField("audio_jack_35", EntoSpecFieldType.Boolean);
		spec.createField("gps_integrated", EntoSpecFieldType.Boolean);
		spec.createField("voice_recorder", EntoSpecFieldType.Boolean);
		spec.createField("loud_speaker", EntoSpecFieldType.Boolean);
		spec.createField("camera_flash", EntoSpecFieldType.Boolean);
		spec.createField("tv_out", EntoSpecFieldType.Boolean);
		spec.createField("radio", EntoSpecFieldType.Boolean);
		spec.createField("nfc", EntoSpecFieldType.Boolean);
		spec.createField("tv_receiver", EntoSpecFieldType.Boolean);
		spec.createField("tech_4g", EntoSpecFieldType.Boolean);
		spec.createField("usb_otg", EntoSpecFieldType.Boolean);

		boolean multivalue = true;
		spec.createField("feature_others", EntoSpecFieldType.VARCHAR_1024, multivalue);
		spec.createField("colors", EntoSpecFieldType.VARCHAR_255, multivalue);

		spec.createField("battery_type", EntoSpecFieldType.VARCHAR_255);
		spec.createField("battery_capa", EntoSpecFieldType.Int);
		spec.createField("battery_voice", EntoSpecFieldType.Decimal);
		spec.createField("battery_standby", EntoSpecFieldType.Decimal);

		spec.createField("weight", EntoSpecFieldType.Decimal);
		spec.createField("size_height", EntoSpecFieldType.Decimal);
		spec.createField("size_width", EntoSpecFieldType.Decimal);
		spec.createField("size_thick", EntoSpecFieldType.Decimal);

		spec.createField("sensor_proxi", EntoSpecFieldType.Boolean);
		spec.createField("sensor_accel", EntoSpecFieldType.Boolean);
		spec.createField("sensor_compass", EntoSpecFieldType.Boolean);
		spec.createField("sensor_gyro", EntoSpecFieldType.Boolean);
		//spec.createField("dual_sim", EntoSpecFieldType.Boolean);
		spec.createField("qwerty_keyboard", EntoSpecFieldType.Boolean);
		
		spec.createField("image_origs", EntoSpecFieldType.SQL_Text, multivalue);
		EntoManager.instance.update(spec);
	}

}
