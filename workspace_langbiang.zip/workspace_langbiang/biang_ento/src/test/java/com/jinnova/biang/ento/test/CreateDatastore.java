package com.jinnova.biang.ento.test;

import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;

public class CreateDatastore {

	/**
	 * @param args
	 * @throws EntoPersistentException 
	 */
	public static void main(String[] args) throws EntoPersistentException {
		EntoManager.initialize();
		EntoManager.instance.createDatastore();
		CreatePrelimitaryData.main(null);
	}

}
