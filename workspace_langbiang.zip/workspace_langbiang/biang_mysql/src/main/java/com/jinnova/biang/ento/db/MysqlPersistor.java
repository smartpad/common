package com.jinnova.biang.ento.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoPersistentException;
import com.jinnova.biang.ento.EntoPersistentProvider;
import com.jinnova.biang.ento.EntoSpec;
import com.jinnova.biang.ento.EntoSpecField;
import com.jinnova.biang.ento.EntoSpecFieldType;

public class MysqlPersistor implements EntoPersistentProvider {
	
	private static final String TABLE_PREFIX = "e_";
	
	private static final String COLUMN_POSTFIX_SUPER = "_id";
	
	private static final String DATA_TYPE_TEXT_ID = "varchar(255)";
	
	private static final String DATA_TYPE_ENTOMETA = "text";
	
	private final HashMap<EntoSpecFieldType, String> fieldTypes = new HashMap<>();
	
	public MysqlPersistor() {
		
		fieldTypes.put(EntoSpecFieldType.Boolean, "boolean");
		fieldTypes.put(EntoSpecFieldType.Int, "int");
		fieldTypes.put(EntoSpecFieldType.Decimal, "decimal");
		fieldTypes.put(EntoSpecFieldType.Text_ID, DATA_TYPE_TEXT_ID);
		fieldTypes.put(EntoSpecFieldType.Text_Name, "varchar(1024)");
		fieldTypes.put(EntoSpecFieldType.Text_Desc, "text");
		fieldTypes.put(EntoSpecFieldType.SQL_Text, "text");
		
		fieldTypes.put(EntoSpecFieldType.VARCHAR_1024, "varchar(1024)");
		fieldTypes.put(EntoSpecFieldType.VARCHAR_512, "varchar(512)");
		fieldTypes.put(EntoSpecFieldType.VARCHAR_255, "varchar(255)");
		
		try {
			Class.forName ("com.mysql.jdbc.Driver").newInstance ();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void createDatastore() throws EntoPersistentException {
		
		Connection conn = null;
		try {
			
			//create database
			String url = "jdbc:mysql://localhost/mysql?useUnicode=yes&characterEncoding=UTF-8";
			conn = DriverManager.getConnection (url, "root", "");
			Statement stmt = conn.createStatement();
			stmt.executeUpdate("create database biang CHARACTER SET utf8");
			conn.close();
			
			//create table ento
			url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
			conn = DriverManager.getConnection (url, "root", "");
			stmt = conn.createStatement();
			/*stmt.executeUpdate("create table ento (" +
					"ento_revision int unsigned AUTO_INCREMENT primary key, " +
					"ento_id int unsigned, " +
					"insert_at datetime, " +
					"insert_by " + DATA_TYPE_TEXT_ID + ", " +
					"settings text, " +
					"index ento_id (ento_id))");*/
			
			//create table ento_hierachy
			stmt.executeUpdate("create table ento_spec (" +
					"id " + DATA_TYPE_TEXT_ID + " not null, " +
					"spec_meta " + DATA_TYPE_ENTOMETA + ", " +
					"insert_at datetime, " +
					"insert_by varchar(255), " +
					"primary key (id))");
			
			//create table ento_asso
			/*stmt.executeUpdate("create table ento_asso (" +
					"ento_from_specid varchar(255) not null, " +
					"ento_from_id int unsigned not null, " +
					"ento_to_specid varchar(255) not null, " +
					"ento_to_id int unsigned not null, " +
					"insert_at datetime, " +
					"insert_by varchar(255), " +
					"primary key (ento_from_specid, ento_from_id, ento_to_specid, ento_to_id))");*/
		} catch (SQLException e) {
			throw new EntoPersistentException(e);
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EntoPersistentException(e);
			}
		}
	}

	@Override
	public void insert(EntoSpec spec) throws EntoPersistentException {
		
		String superEntoDefs = null;
		List<EntoSpec> superSpecs = spec.getSuperSpecsDirect();
		if (superSpecs != null) {
			for (EntoSpec oneSuperSpec : superSpecs) {
				/*if (oneSuperSpec == EntoManager.instance.rootSpec) {
					continue;
				}*/
				String oneDef = oneSuperSpec.specId + "_id int unsigned";
				if (superEntoDefs == null) {
					superEntoDefs = oneDef;
				} else {
					superEntoDefs = superEntoDefs + ", " + oneDef;
				}
			}
		}
		
		String colDefs = null; //"ento_revision int unsigned not null";
		Iterator<EntoSpecField> it = spec.getAllFields().iterator();
		while (it.hasNext()) {
			EntoSpecField f = it.next();
			String oneDef = f.id + " " + fieldTypes.get(f.fieldType);
			if (colDefs == null) {
				colDefs = oneDef;
			} else {
				colDefs = colDefs + ", " + oneDef;
			}
		}
		
		Connection conn = null;
		try {
			String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
			conn = DriverManager.getConnection (url, "root", "");
			Statement stmt = conn.createStatement();
			String allColDefs;
			if (superEntoDefs == null) {
				//superEntoDefs = "";
				allColDefs = colDefs;
			} else {
				//superEntoDefs = superEntoDefs + ", ";
				allColDefs = superEntoDefs + ", " + colDefs;
			}
			String sql = "create table " + TABLE_PREFIX + spec.specId + 
					"(id int unsigned AUTO_INCREMENT primary key, " +
					allColDefs + ", ento_meta " + DATA_TYPE_ENTOMETA + ", " +
					"insert_at datetime, insert_by " + DATA_TYPE_TEXT_ID + ")";
					//"CONSTRAINT foreign key (ento_revision) references ento(ento_revision))";
			System.out.println("SQL: " + sql);
			stmt.executeUpdate(sql);
			
			//List<EntoExtension> allextensions = spec.getSuperSpecs();
			/*if (superSpecs != null) {
				for (EntoSpec one : superSpecs) {
					if (one == EntoManager.instance.rootSpec) {
						continue;
					}
					sql = "insert into ento_hierachy (ento_specid, ento_specid_parent) values ('" +
							spec.specId + "', '" + one.specId + "')";
					stmt.executeUpdate(sql);
				}
			}*/
			
			String specMetaString = spec.getMetaString();
			specMetaString = "'" + specMetaString + "'";
			sql = "insert into ento_spec (id, spec_meta) values ('" +
					spec.specId + "', " + specMetaString + ")";
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			throw new EntoPersistentException(e);
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EntoPersistentException(e);
			}
		}
	}

	@Override
	public void update(EntoSpec spec) throws EntoPersistentException {
		
		Connection conn = null;
		try {
			String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
			conn = DriverManager.getConnection (url, "root", "");
			Statement stmt = conn.createStatement();
			Iterator<EntoSpecField> it = spec.getAllFields().iterator();
			while (it.hasNext()) {
				EntoSpecField f = it.next();
				if (!f.isPersistStateNew()) {
					continue;
				}
				String oneDef = f.id + " " + fieldTypes.get(f.fieldType);
				String sql = "alter table " + TABLE_PREFIX + spec.specId + " add column " + oneDef;
				System.out.println("SQL: " + sql);
				stmt.executeUpdate(sql);
				f.clearPersistState();
			}
			
			//update meta
			String specMetaString = spec.getMetaString();
			String sql = "update ento_spec set spec_meta='" + specMetaString + "' where id='" + spec.specId + "'";
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			throw new EntoPersistentException(e);
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EntoPersistentException(e);
			}
		}
	}

	@Override
	public long insert(Ento ento) throws EntoPersistentException {
		
		String colNames = null; //"ento_revision";
		String colMarks = null; //"?";
		Iterator<EntoSpec> itSpec = ento.spec.getSuperSpecsDirectIterator();
		while (itSpec.hasNext()) {
			EntoSpec oneSuperSpec = itSpec.next();
			/*if (oneSuperSpec == EntoManager.instance.rootSpec) {
				continue;
			}*/
			String oneName = oneSuperSpec.specId + COLUMN_POSTFIX_SUPER;
			if (colNames == null) {
				colNames = oneName;
				colMarks = "?";
			} else {
				colNames = colNames + ", " + oneName;
				colMarks = colMarks + ", ?";
			}
		}
		Iterator<EntoSpecField> itEnto = ento.spec.getAllFields().iterator();
		while (itEnto.hasNext()) {
			EntoSpecField f = itEnto.next();
			if (colNames == null) {
				colNames = f.id;
				colMarks = "?";
			} else {
				colNames = colNames + ", " + f.id;
				colMarks = colMarks + ", ?";
			}
		}
		
		Connection conn = null;
		try {
			String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
			conn = DriverManager.getConnection (url, "root", "");
			//long newEntoRevision = insertEntoBase(conn, ento);
			
			String sql = "insert into " + TABLE_PREFIX + ento.spec.specId + " (" + colNames + ") values " + " (" + colMarks + ")";
			System.out.println("SQL: " + sql);
			PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			itSpec = ento.spec.getSuperSpecsDirectIterator();
			//ps.setLong(i++, newEntoRevision);
			while (itSpec.hasNext()) {
				EntoSpec f = itSpec.next();
				/*if (f == EntoManager.instance.rootSpec) {
					continue;
				}*/
				ps.setLong(i++, ento.getSuperEnto(f).getId());
			}
			itEnto = ento.spec.getAllFields().iterator();
			//ps.setLong(i++, newEntoRevision);
			while (itEnto.hasNext()) {
				EntoSpecField f = itEnto.next();
				ps.setString(i++, ento.getFieldValueSerialized(f.id));
			}
			ps.executeUpdate();
			ResultSet rs = ps.getGeneratedKeys();
			rs.next();
			return rs.getLong(1);
			//return newEntoRevision;
		} catch (SQLException e) {
			throw new EntoPersistentException(e);
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EntoPersistentException(e);
			}
		}
	}

	@Override
	public void update(Ento ento) throws EntoPersistentException {
		update(ento, null);
	}

	@Override
	public PreparedStatement update(Ento ento, final Object psParam) throws EntoPersistentException {
		
		String exprs = "update_at=?,update_by=?";
		Iterator<EntoSpecField> itEnto = ento.spec.getAllFields().iterator();
		while (itEnto.hasNext()) {
			EntoSpecField f = itEnto.next();
			/*if (exprs == null) {
				exprs = f.id + "=?";
			} else {
				exprs = exprs + ", " + f.id + "=?";
			}*/
			exprs = exprs + ", " + f.id + "=?";
		}
		
		Connection conn = null;
		try {
			//long newEntoRevision = insertEntoBase(conn, ento);
			PreparedStatement ps;
			if (psParam == null || !(psParam instanceof PreparedStatement)) {
				String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
				conn = DriverManager.getConnection (url, "root", "");
				String sql = "update " + TABLE_PREFIX + ento.spec.specId + " set " + exprs + " where id=?";
				System.out.println("SQL: " + sql);
				ps = conn.prepareStatement(sql);
			} else {
				ps = (PreparedStatement) psParam;
			}
			int i = 1;
			itEnto = ento.spec.getAllFields().iterator();
			//ps.setLong(i++, newEntoRevision);
			ps.setTimestamp(i++, new Timestamp(System.currentTimeMillis()));
			ps.setString(i++, ento.getUpdateBy());
			while (itEnto.hasNext()) {
				EntoSpecField f = itEnto.next();
				ps.setString(i++, ento.getFieldValueSerialized(f.id));
			}
			ps.setLong(i++, ento.getId());
			ps.executeUpdate();
			//return newEntoRevision;
			return ps;
		} catch (SQLException e) {
			throw new EntoPersistentException(e);
		} finally {
			if (psParam == null) {
				try {
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException e) {
					throw new EntoPersistentException(e);
				}
			}
		}
	}

	@Override
	public HashMap<String, String> loadHierachy() throws EntoPersistentException {
		Connection conn = null;
		try {
			String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
			conn = DriverManager.getConnection (url, "root", "");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from ento_spec");
			HashMap<String, String> hierachyMap = new HashMap<>();
			while (rs.next()) {
				hierachyMap.put(rs.getString("id"), rs.getString("spec_meta"));
			}
			return hierachyMap;
		} catch (SQLException e) {
			throw new EntoPersistentException(e);
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EntoPersistentException(e);
			}
		}
	}

	@Override
	public void loadEntos(EntoSpec spec, Object jsonParser) throws EntoPersistentException {
		
		Connection conn = null;
		try {
			String url = "jdbc:mysql://localhost/biang?useUnicode=yes&characterEncoding=UTF-8";
			conn = DriverManager.getConnection (url, "root", "");
			Statement stmt = conn.createStatement();
			String sql = "select * from " + TABLE_PREFIX + spec.specId;
			System.out.println("SQL: " + sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				
				//load fields
				Ento ento = spec.createEnto(null);
				Iterator<EntoSpecField> fieldIt = spec.getAllFields().iterator();
				while (fieldIt.hasNext()) {
					EntoSpecField field = fieldIt.next();
					//System.out.println("Loaded: " + rs.getString(field.id));
					try {
						ento.loadFieldValueSerialized(field.id, rs.getString(field.id), jsonParser);
					} catch (SQLException e) {
						//column not found, ignore
						System.out.println("SQLException: " + e.getMessage());
					}
				}
				
				//load super ids / meta
				HashMap<String, Long> superIds = new HashMap<>();
				for (EntoSpec oneSuper : spec.getSuperSpecsDirect()) {
					superIds.put(oneSuper.specId, rs.getLong(oneSuper.specId + COLUMN_POSTFIX_SUPER));
					System.out.println("super id: " + oneSuper.specId + "/" + superIds.get(oneSuper.specId));
				}
				spec.load(rs.getLong("id"), ento, superIds, rs.getString("ento_meta"), jsonParser);
			}
		} catch (SQLException e) {
			throw new EntoPersistentException(e);
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new EntoPersistentException(e);
			}
		}
	}

	/*private long insertEntoBase(Connection conn, Ento ento) throws SQLException {
		
		String sql = "insert into ento (insert_at, insert_by) values (?, ?)";
		System.out.println("SQL: " + sql);
		PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		ResultSet rs = null;
		Statement stmt = null;
		try {
			int i = 1;
			ps.setTimestamp(i++, new Timestamp(System.currentTimeMillis()));
			ps.setString(i++, null); //TODO insert by
			ps.executeUpdate();
			rs = ps.getGeneratedKeys();
			rs.next();
			long newRevisionNumber = rs.getLong(1);
			
			stmt = conn.createStatement();
			stmt.executeUpdate("update ento set ento_id=ento_revision where ento_revision = " + newRevisionNumber);
			return newRevisionNumber;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (ps != null) {
				ps.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
	}*/
}
