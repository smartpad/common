package com.jinnova.biang.core.test;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.jinnova.biang.core.Bootstrap;
import com.jinnova.biang.core.ListingService;
import com.jinnova.biang.ento.EntoPersistentException;

public class ListingTest {

	/**
	 * @param args
	 * @throws EntoPersistentException 
	 */
	public static void main(String[] args) throws EntoPersistentException {
		Bootstrap.initialize();
		JsonObject o = new ListingService().getListing("master_cat", 1);
		String s = new GsonBuilder().setPrettyPrinting().create().toJson(o);
		System.out.println(s);
	}

}
