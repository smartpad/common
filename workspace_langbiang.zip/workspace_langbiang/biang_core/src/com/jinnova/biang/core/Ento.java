package com.jinnova.biang.core;

/**
 * @author Huy Banh
 * 
 * All entos are rooted at Ento
 * 
 * For each ento, there are two tables:
 *    + e_<ento_name>: ento data
 *    + a_<ento_name>: app data for each ento data record
 *    
 * e_ento table is a preinstalled table, the root of all other entos
 * 
 * e_ento table has only two columns: revision and ento_id
 *
 */
public class Ento {
	
	private int id;
	
	private int revision;

}
