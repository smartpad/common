package com.jinnova.biang.core;

public class EntoSpecField {
	
	private final String name;

	EntoSpecField(String name) {
		this.name = name;
	}
}
