package com.jinnova.biang.core;

public enum EntoSpecFieldType {

}
