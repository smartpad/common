package com.jinnova.biang.core;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class EntoSpec {
	
	private static EntoSpec ento;
	
	private final LinkedList<EntoSpec> superSpecs = new LinkedList<>();
	
	private final LinkedList<EntoSpecField> allFields = new LinkedList<>();
	
	private final HashSet<HashSet<EntoSpecField>> uniqueKeys = new HashSet<>();
	
	public static void initialize() {
		if (ento != null) {
			return;
		}
		ento = new EntoSpec();
		ento.allFields.add(new EntoSpecField("revision"));
		ento.allFields.add(new EntoSpecField("ento_id"));
	}

	public List<EntoSpec> getSuperSpecs() {
		return new LinkedList<>(superSpecs);
	}
	
	public List<EntoSpec> getSuperSpecsAll() {
		return null; //TODO
	}
}
