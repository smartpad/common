package com.jinnova.biang.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jinnova.biang.ento.Ento;
import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoSpec;

public class ListingService {

	public ListingService() {
	}
	
	public JsonObject getListing(String catId, long itemId) {
		
		JsonObject resultJson = new JsonObject();
		EntoSpec spec = EntoManager.instance.getSpec(catId);
		if (spec == null) {
			resultJson.addProperty("error", "Unexisting category: " + catId);
			return resultJson;
		}
		Ento ento = spec.getEnto(itemId);
		if (ento == null) {
			resultJson.addProperty("error", "Unexisting item: " + itemId);
			return resultJson;
		}
		
		//item json
		JsonObject itemJson = new JsonObject();
		itemJson.addProperty("id", ento.getId());
		
		//item spec
		JsonObject specJson = new JsonObject();
		specJson.addProperty("id", spec.specId);
		//specJson.addProperty("name", spec.getSuperSpecsDirect());
		itemJson.add("spec", specJson);
		
		//fields
		JsonObject fieldJson = new ItemMarshaller().buildFieldJson(ento);
		itemJson.add("fields", fieldJson);
		
		//sibling cats
		JsonArray sibArray = new JsonArray();
		for (Ento sib : spec.getAllEntos()) {
			if (sib == ento) {
				continue;
			}
			JsonObject sibJson = new JsonObject();
			sibJson.addProperty("id", sib.getId());
			sibJson.addProperty("name", sib.getFieldValue("name"));
			sibArray.add(sibJson);
		}
		resultJson.add("item", itemJson);
		
		//sub cats
		JsonArray subArray = new JsonArray();
		for (Ento sub : ento.getSubEntos(true)) {
			JsonObject subJson = new JsonObject();
			subJson.addProperty("id", sub.getId());
			subJson.addProperty("name", sub.getFieldValue("name"));
			subJson.addProperty("spec", sub.spec.specId);
			subArray.add(subJson);
		}
		resultJson.add("subCats", subArray);
		
		resultJson.add("sibCats", sibArray);
		return resultJson;
	}

}
