package com.jinnova.biang.core;

import java.util.Map.Entry;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.jinnova.biang.ento.Ento;

class ItemMarshaller {

	JsonObject buildFieldJson(Ento ento) {
		JsonObject fieldJson = new JsonObject();
		for (Entry<String, JsonElement> field : ento.getAllFields().entrySet()) {
			fieldJson.add(field.getKey(), field.getValue());
		}
		fieldJson.add("meta", ento.getMeta());
		return fieldJson;
	}

}
