package com.jinnova.biang.core;

import com.jinnova.biang.ento.EntoManager;
import com.jinnova.biang.ento.EntoPersistentException;

public class Bootstrap {

	public static void initialize() throws EntoPersistentException {
		EntoManager.initialize();
		EntoManager.instance.load();
	}
}
